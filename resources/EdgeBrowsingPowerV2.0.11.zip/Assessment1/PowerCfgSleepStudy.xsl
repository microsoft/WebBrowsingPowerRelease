<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:SleepStudy="http://schemas.microsoft.com/sleepstudy/2012"
                exclude-result-prefixes="SleepStudy"
                version="1.0">
  <!--xmlns:n1="http://schemas.microsoft.com/sleepstudy/2012"-->

  <xsl:output method="xml" indent="yes" />
  <xsl:template name="sum">
    <xsl:param name="nodes" />
    <xsl:param name="sum" select="0" />

    <xsl:variable name="curr" select="$nodes[1]" />

    <!-- if we have a node, calculate & recurse -->
    <xsl:if test="$curr">
      <xsl:variable name="runningsum" select="$sum + ($curr/@ActiveTime div 1000)" />
      <xsl:call-template name="sum">
        <xsl:with-param name="nodes" select="$nodes[position() &gt; 1]" />
        <xsl:with-param name="sum"   select="$runningsum" />
      </xsl:call-template>
    </xsl:if>

    <!-- if we don't have a node (last recursive step), return sum -->
    <xsl:if test="not($curr)">
      <xsl:value-of select="round($sum div 100) div 100" />
    </xsl:if>

  </xsl:template>
  <xsl:template match="/">
    <AssessmentResult>
      <Iterations>
        <xsl:for-each select="/SleepStudy:SleepStudy/SleepStudy:ScenarioInstances/SleepStudy:ScenarioInstance[@Scenario='ConnectedStandby']">
          <Iteration>
            <TestCases>
              <TestCase>
                <Key>ConnectedStandby_EnergyWorkload</Key>
                <Name>Modern Standby Sleep Study Results - Instance #</Name>
                <MetricValues>
                  <MetricValue>
                    <Value>
                      <xsl:variable name ="cs_duration" select="@CsDuration" />
                      <xsl:variable name ="drips_duration" select="@LowPowerStateTime" />
                      <xsl:value-of select="round(($drips_duration div $cs_duration) * 100  * 100) div 100" />
                    </Value>
                    <ProgrammaticName>DripsPercentTime</ProgrammaticName>
                  </MetricValue>
                  <MetricValue>
                    <Value>
                      <xsl:variable name ="time_stamp" select="@TimeStamp"  />
                      <xsl:value-of select="$time_stamp"/>
                    </Value>
                    <ProgrammaticName>ScenarioTimeStamp</ProgrammaticName>
                  </MetricValue>
                </MetricValues>
                <Parents>
                  <Parent>Workloads</Parent>
                </Parents>
              </TestCase>
              <TestCase>
                <Key>ConnectedStandby-Resiliency</Key>
                <Name>Resiliency/In Modern Standby</Name>
                <MetricValues>
                  <MetricValue>
                    <Value>
                      <xsl:variable name ="cs_duration_resiliencynode" select="@CsDuration" />
                      <xsl:value-of select="round($cs_duration_resiliencynode div 100) div 100 div 1000" />
                    </Value>
                    <ProgrammaticName>Duration_sec</ProgrammaticName>
                  </MetricValue>
                </MetricValues>
                <Parents>
                  <Parent>Phases</Parent>
                  <Parent>ConnectedStandby_EnergyWorkload</Parent>
                </Parents>
              </TestCase>
              <xsl:if test="count(./SleepStudy:Devices/SleepStudy:Device) > 0 ">
                <TestCase>
                  <Key>Devices</Key>
                  <Name>Devices</Name>
                  <Parents>
                    <Parent>ConnectedStandby-Resiliency</Parent>
                  </Parents>
                </TestCase>
                <!-- Loop over every device in the Devices node and generate metrics -->
                <xsl:for-each select="./SleepStudy:Devices/SleepStudy:Device">
                  <TestCase>
                    <xsl:variable name="name" select="@Name" />
                    <Key>Devices-<xsl:value-of select="$name"/></Key>
                    <Name>
                      <xsl:value-of select="$name"/>
                    </Name>
                    <MetricValues>
                      <MetricValue>
                        <Value>
                          <xsl:choose>
                            <xsl:when test="count(./SleepStudy:Component) > 0">
                              <xsl:for-each select="./SleepStudy:Component[1]" >
                                <xsl:variable name="active_time" select="@ActiveTime" />
                                <xsl:value-of select="round($active_time div 100) div 100 div 1000" />
                              </xsl:for-each>
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:variable name="active_time" select="@ActiveTime" />
                              <xsl:value-of select="round($active_time div 100) div 100 div 1000" />
                            </xsl:otherwise>
                          </xsl:choose>
                        </Value>
                        <ProgrammaticName>Duration_sec</ProgrammaticName>
                      </MetricValue>
                      <MetricValue>
                        <Value>
                          <xsl:for-each select="./SleepStudy:Component[1]" >
                            <xsl:variable name="active_time_percent" select="@ActiveTimePercent" />
                            <xsl:value-of select="$active_time_percent" />
                          </xsl:for-each>
                        </Value>
                        <ProgrammaticName>Duration_percent</ProgrammaticName>
                      </MetricValue>
                    </MetricValues>
                    <Parents>
                      <Parent>Devices</Parent>
                    </Parents>
                  </TestCase>
                </xsl:for-each>
              </xsl:if>
              <!-- End loop over each Device in the Devices section -->
              <!-- Loop over the activators and generate metrics -->
              <xsl:for-each select="./SleepStudy:Activators/SleepStudy:Activator">
                <TestCase>
                  <xsl:variable name="name" select="@Name" />
                  <Key>
                    <xsl:value-of select="$name"/>
                  </Key>
                  <Name>
                    <xsl:value-of select="$name"/>
                  </Name>
                  <MetricValues>
                    <MetricValue>
                      <Value>
                        <xsl:variable name="active_time" select="@ActiveTime" />
                        <xsl:value-of select="round($active_time div 100) div 100 div 1000" />
                      </Value>
                      <ProgrammaticName>Duration_sec</ProgrammaticName>
                    </MetricValue>
                    <MetricValue>
                      <Value>
                        <xsl:variable name="active_time_percent" select="@ActiveTimePercent" />
                        <xsl:value-of select="$active_time_percent" />
                      </Value>
                      <ProgrammaticName>Duration_percent</ProgrammaticName>
                    </MetricValue>
                  </MetricValues>
                  <Parents>
                    <Parent>ConnectedStandby-Resiliency</Parent>
                  </Parents>
                </TestCase>
              </xsl:for-each>
              <!-- End loop over each Activator -->
              <TestCase>
                <Key>EnterExitCs</Key>
                <Name>Entering + Exiting Modern Standby</Name>
                <MetricValues>
                  <MetricValue>
                    <Value>
                      <!-- call the sum function (with the relevant nodes) -->
                      <xsl:call-template name="sum">
                        <xsl:with-param name="nodes" select="./SleepStudy:Phases/SleepStudy:Phase[@Name!='No CS Phase' and @Name!='Resiliency Phase']" />
                      </xsl:call-template>
                    </Value>
                    <ProgrammaticName>Duration_sec</ProgrammaticName>
                  </MetricValue>
                </MetricValues>
                <Parents>
                  <Parent>ConnectedStandby-Resiliency</Parent>
                </Parents>
              </TestCase>
            </TestCases>
          </Iteration>
        </xsl:for-each>
        <!-- End loop over each ScenarioInstance in the ScenarioInstances section -->
      </Iterations>
    </AssessmentResult>
  </xsl:template>
</xsl:stylesheet>
