$POWERCONFGIG_OUTPUT_FOLDER            = "PowerConfig"
$POWERCONFGIG_SYSTEM_POWER_REPORT_HTML = "PowerCfg-SleepStudyReport.html"
$POWERCONFGIG_TIMEOUT_SEC              = 10 * 60

Add-Type -TypeDefinition @'

using System;
using System.Runtime.InteropServices;

namespace DllAPI
{
    public class Kernel32Call
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        static extern int GetCurrentProcess();

        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        static extern bool IsWow64Process(int proc, out int isWow64);

        public int dll_GetCurrentProcess()
        {
            return GetCurrentProcess();
        }

        public bool dll_IsWow64Process(int proc)
        {
            int isWow64 = 0;
            bool ret = IsWow64Process(proc, out isWow64);
            if (ret == false)
            {
                return false;
            }
            else
            {
                if (isWow64 != 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    } // End -- Kernel32Call Class
}
'@

$Kern32Call = New-Object -TypeName DllAPI.Kernel32Call

function Write-PowerConfigSystemPowerReport {
param (
    [parameter(Mandatory=$true)][string]$ResultPath
)
    $DestDir = Join-Path -Path $ResultPath -ChildPath $POWERCONFGIG_OUTPUT_FOLDER
    if (-not (Test-Path "$DestDir" -pathType container))
    {
        New-Item $DestDir -ItemType directory > $null
    }

    $options = "-systempowerreport -output `"$DestDir\$POWERCONFGIG_SYSTEM_POWER_REPORT_HTML`""
    $CurrProc = $Kern32Call.dll_GetCurrentProcess();
    $isWow64 = $Kern32Call.dll_IsWow64Process($CurrProc);

    if ($isWow64)
    {
        $powerCfgPath = "$env:windir\Sysnative\"
    }
    else
    {
        $powerCfgPath = "$env:windir\System32\"
    }

    $_cmdletExist = Get-Command DisableWow64FsRedirection; if ( $_cmdletExist ) { DisableWow64FsRedirection };
    $proc = Start-Process "$powerCfgPath\powercfg.exe" -ArgumentList "$Options" `
        -NoNewWindow -PassThru
    $_cmdletExist = Get-Command RevertWow64FsRedirection ; if ( $_cmdletExist ) { RevertWow64FsRedirection };

    try
    {
        $proc | Wait-Process -Timeout $POWERCONFGIG_TIMEOUT_SEC -ErrorAction Stop
    }
    catch
    {
        $proc | Stop-Process
        throw "The powercfg.exe exceeded timeout, it will be killed."
    }
}

Export-ModuleMember -Function Write-PowerConfigSystemPowerReport

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB9E5Y/8+WFcpr9
# AglnEoqyxEokk/6yHOpQlbg2bYNkqKCCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQg9OPDkSEe
# +Jj/MMgzM7gH9kC2vZuS2hK76CAB0rGCiIYwDQYJKoZIhvcNAQEBBQAEggEAoRyg
# fNJHNxY4xWC0USW7qbUiemphmhiIKUtl+ViVdQT0DGE9sm3H53oxDesTOIhs0mfA
# MsXFabhwiq7CDOtx3VKQjKQL83FojhR+qw3iQ6VLDLGapOIhjllBFXsmMiu6RZ6V
# RIi5p0CdDmX4Q0siXbfY+zlhiA33HMQxiRbHwMtXrnDo2daluxRR/5WCKyaG1lFa
# EDvZAOM7ewrKvozOV1X9IpskN59s4++CcmHP9k4hGVyo8KRNQ0xJy2PUq2ONrUOi
# b3OR1ZHnfQfp0ECfGCk1I5eiZ6gtZ+qxFSmzZ4regPIFOeMhVW2yfhQD1uJ9tguV
# tOtHKZ5MqmqhsPugEg==
# SIG # End signature block
