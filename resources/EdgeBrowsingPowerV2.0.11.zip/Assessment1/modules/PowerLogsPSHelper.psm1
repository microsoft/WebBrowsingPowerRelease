# Need to know where our script is so we can use full path to all our dependent files.
$InvocationPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

function Get-ComputerName()
{
    return [system.environment]::MachineName
}

function Start-PowerLogs {
param (
    [parameter(Mandatory=$true)][string]$PowerLogsPath
)
    # change to $PowerLogsPath directory
    Set-Location -Path "$PowerLogsPath"
            
    # netsh trace start scenario=WLAN maxSize=400 tracefile=mytrace.etl report=yes perfmerge=yes
    $destDir = "$PowerLogsPath\tempFiles"
    $FilesToCab = $null
    $LatestPerftraceEtl = $null
    $LatestDripsWatchdogLiveDump = $null

    $MYHOST = Get-ComputerName
    "$MYHOST" | Set-Content "$PowerLogsPath\out.txt"

    if (-not (Test-Path "$destDir" -pathType container))
    {
        # Path for tempFiles
        "Creating tempFiles directory" | Add-Content "$PowerLogsPath\out.txt"
        New-Item $destDir -ItemType directory 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    }

    Write-Host "Copying Windows Update logs"
    "Copying Windows Update logs" | Add-Content "$PowerLogsPath\out.txt"
    $windowsUpdateLogs = "$env:systemroot\windowsupdate.log"
    if ((Test-Path "$windowsUpdateLogs" -pathType leaf))
    {
        Copy-Item $windowsUpdateLogs $destDir -Force 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    }

    Write-Host "Copying Windows Live Logs"
    "Copying Windows Live Logs" | Add-Content "$PowerLogsPath\out.txt"
    $windowsLiveLogs = "$env:localappdata\Packages\microsoft.windowscommunicationsapps_8wekyb3d8bbwe\LocalState\*.etl"
    Copy-Item $windowsLiveLogs $destDir -Force 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    Write-Host "Copying Network Information"
    "Copying Network Information" | Add-Content "$PowerLogsPath\out.txt" 
    $netTraceCab = "$env:TEMP\NetTraces\NetTrace.cab"
    if ((Test-Path $netTraceCab -pathType leaf))
    {
        Copy-Item $netTraceCab $destDir -Force 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    }
    cmd.exe /c "route print > `"$destDir\route-nic-id.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "ipconfig /all > `"$destDir\ipconfig-out.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    Write-Host "Flushing always on network tracing"
    "Flushing always on network tracing" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "LogMan Update LwtNetLog -fd -ets" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "netsh trace merge %SystemRoot%\System32\LogFiles\WMI\LwtNetLog.etl `"$destDir\LwtNetLog-merged.etl`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    $wifiEtl = "$env:SystemRoot\System32\LogFiles\WMI\Wifi.etl"
    Copy-Item $wifiEtl $destDir -Force 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    
    Write-Host "Capturing BCD information"
    "Capturing BCD information" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "bcdedit > `"$destDir\bcdedit-out.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    Write-Host "Capturing Bitlocker status"
    "Capturing Bitlocker status" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "manage-bde -status > `"$destDir\bde-status-out.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    # look for Drivers that are missing (code ">28<" or ">43<" or ">52<")
    Write-Host "Capturing PNP Information"
    "Capturing PNP Information" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "ddodiag -o `"$destDir\ddodiag-driverInstall.xml`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    # get some dxdiag output for device tree
    cmd.exe /c "dxdiag /whql:off /t `"$destDir\dxdiag_out.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "driverquery.exe /FO TABLE /V > `"$destDir\$MYHOST.Drivers.log`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    
    Write-Host "Capturing System information"
    "Capturing System information" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "systeminfo > `"$destDir\systeminfo.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "msinfo32.exe /nfo `"$destDir\$MYHOST.SystemInfo.nfo`" /categories +all" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "reg query `"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion`" /v BuildLab > `"$destDir\osver.txt`"" 2>&1 | `
        Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "reg query `"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System`" /f SystemBios >> `"$destDir\osver.txt`"" 2>&1 | `
        Add-Content "$PowerLogsPath\out.txt"

    Write-Host "Capturing Power Configuration"
    "Capturing Power Configuration" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /qh > `"$destDir\powercfg.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg a > `"$destDir\powercfg-a.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /requests > `"$destDir\powercfg-requests.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    # Registry power settings
    cmd.exe /c "reg save HKLM\System\CurrentControlSet\Control `"$destDir\powersettings_REG`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    Write-Host "Capturing PowerCfg Logs"
    "Capturing PowerCfg Logs" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "wevtutil qe System /q:`"*[System[(EventID=506 or EventID=507 or EventID=109) and TimeCreated[timediff(@SystemTime) <= 259200000]]]`" /c:100 /f:renderedXml > `"$destDir\cs-exit-events.xml`"" 2>&1 | `
        Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "wevtutil qe System /q:`"*[System[EventID=520 and TimeCreated[timediff(@SystemTime) <= 259200000]]]`" /c:100 /f:TEXT > `"$destDir\%COMPUTERNAME%.BrightnessEngine.log`"" 2>&1 | `
        Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "wevtutil epl System `"$destDir\SystemEventLog.evt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "wevtutil epl Microsoft-Windows-TaskScheduler/Operational `"$destDir\tasksOperational.evt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "wevtutil epl Microsoft-Windows-GroupPolicy/Operational `"$destDir\gplog.evt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "wevtutil epl Microsoft-Windows-PushNotification-Platform/Operational `"$destDir\PushNotificationOp.evt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /srumutil output `"$destDir\srumutil-$MYHOST.csv`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /batteryreport output `"$destDir\battery-report-$MYHOST.html`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /sleepstudy output `"$destDir\sleepstudy-report-$MYHOST.html`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /sleepstudy /duration 20 /output `"$destDir\long20-sleepstudy-report-$MYHOST.html`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /sleepstudy /duration 10 /output `"$destDir\long10-sleepstudy-report-$MYHOST.html`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /sleepstudy /duration 5  /output `"$destDir\long5-sleepstudy-report-$MYHOST.html`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /sleepstudy /duration 10 /output `"$destDir\sleepstudy-report-$MYHOST.xml`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /systemsleepdiagnostics /output `"$destDir\system-sleep-diagnostics-$MYHOST`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    $sleepStudyEtls = "$env:windir\system32\SleepStudy\*.etl"
    Copy-Item $sleepStudyEtls $destDir -Force 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    
    "" | Add-Content "$PowerLogsPath\out.txt"
    "Starting Energy Analysis ..." | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "powercfg /energy output `"$destDir\energy-report-$MYHOST.html`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    "Capturing telemetry MachineId" | Add-Content "$PowerLogsPath\out.txt"
    cmd.exe /c "reg query `"HKLM\Software\Microsoft\SQMClient`" /v MachineId > `"$destDir\machine_id.txt`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    "" | Add-Content "$PowerLogsPath\out.txt"
    "Generating CAB file ..." | Add-Content "$PowerLogsPath\out.txt"

    ".OPTION EXPLICIT" | Set-Content "$destDir\input.ddf"
    "" | Add-Content "$destDir\input.ddf"
    ".Set CabinetName1=PowerLogs.CAB" | Add-Content "$destDir\input.ddf"
    ".Set DiskDirectory1=..\output" | Add-Content "$destDir\input.ddf"
    ".Set MaxDiskSize=0" | Add-Content "$destDir\input.ddf"
    ".Set Cabinet=on" | Add-Content "$destDir\input.ddf"
    ".Set Compress=on" | Add-Content "$destDir\input.ddf"
    cmd.exe /c "dir /b $destDir | findstr /v exclude | findstr /v setup  | findstr /v disk |findstr /v input.ddf >> `"$destDir\input.ddf`"" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    Set-Location -Path $destDir
    cmd.exe /c "makecab /f input.ddf" 2>&1 | Add-Content "$PowerLogsPath\out.txt"

    "" | Add-Content "$PowerLogsPath\out.txt"
    Set-Location -Path $PowerLogsPath
    cmd.exe /c "dir output" 2>&1 | Add-Content "$PowerLogsPath\out.txt"
    Remove-Item $destDir -Force -Recurse 2>&1 | Add-Content "$PowerLogsPath\out.txt"
}

Export-ModuleMember -Function Start-PowerLogs

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDcxqReMup4+POM
# ptiGVU8UExGJ4Edt+g6Uy8ZqGsKRy6CCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQgLHJkO1C8
# NnNJwtS/nB8g4czKHzpXk9Dlrnk9XfbQgzgwDQYJKoZIhvcNAQEBBQAEggEAI6DK
# 3C2Ih+HnlXw5FP2yi1QqOS6iT17EqNyAnR6cDg/B0ghNRRy+Dbg+X1QBnHJyWqJ1
# q+w2vHjKPVzvZxo4emjd/NaT22VVzN+elqpu57y0/kNXArT7KKtTpRTXbRuc9e/7
# AjvkcIAXo4HMdqTaSUFIJ/Ttj9ntc3gsX7+zBzrV7WEiwtMJL4YTtzyTePxIRjpB
# x4oz/9wJiJbdRzoOEz8JoE0EgiBzn9P8zqRpVJ1x+KIHWBP7rQmaFFryUYhSXAX3
# XpKL/c5AaT3qCEOk5+a2o11fiCKY3igxAb8ENEr2Q4MQf7j+4R+6qOnI5kg+zuk/
# iZSCrmMnHo+/rg22nA==
# SIG # End signature block
