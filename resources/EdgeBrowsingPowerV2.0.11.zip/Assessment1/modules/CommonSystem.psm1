$InvocationPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

Add-Type -TypeDefinition @'

using System;
using System.Runtime.InteropServices;

namespace DynaLoadAPI
{
    public class NtPowerCall
    {
        public enum SYSTEM_POWER_STATE
        {
            PowerSystemUnspecified = 0,
            PowerSystemWorking = 1,
            PowerSystemSleeping1 = 2,
            PowerSystemSleeping2 = 3,
            PowerSystemSleeping3 = 4,
            PowerSystemHibernate = 5,
            PowerSystemShutdown = 6,
            PowerSystemMaximum = 7
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct BATTERY_REPORTING_SCALE
        {                                                   // typedef struct {
            public uint Granularity;                        //    DWORD       Granularity;
            public uint Capacity;                           //    DWORD       Capacity;
        }                                                   //} BATTERY_REPORTING_SCALE, *PBATTERY_REPORTING_SCALE;

        [StructLayout(LayoutKind.Sequential)]
        public struct SYSTEM_POWER_CAPABILITIES
        {                                                   // typedef struct {
                                                            //   // Misc supported system features
            public byte PowerButtonPresent;                 //   BOOLEAN                 PowerButtonPresent;
            public byte SleepButtonPresent;                 //   BOOLEAN                 SleepButtonPresent;
            public byte LidPresent;                         //   BOOLEAN                 LidPresent;
            public byte SystemS1;                           //   BOOLEAN                 SystemS1;
            public byte SystemS2;                           //   BOOLEAN                 SystemS2;
            public byte SystemS3;                           //   BOOLEAN                 SystemS3;
            public byte SystemS4;           // hibernate    //   BOOLEAN                 SystemS4;
            public byte SystemS5;           // off          //   BOOLEAN                 SystemS5;
            public byte HiberFilePresent;                   //   BOOLEAN                 HiberFilePresent;
            public byte FullWake;                           //   BOOLEAN                 FullWake;
            public byte VideoDimPresent;                    //   BOOLEAN                 VideoDimPresent;
            public byte ApmPresent;                         //   BOOLEAN                 ApmPresent;
            public byte UpsPresent;                         //   BOOLEAN                 UpsPresent;

                                                            //   // Processors
            public byte ThermalControl;                     //   BOOLEAN                 ThermalControl;
            public byte ProcessorThrottle;                  //   BOOLEAN                 ProcessorThrottle;
            public byte ProcessorMinThrottle;               //   BYTE                    ProcessorMinThrottle;
            public byte ProcessorMaxThrottle;               //   BYTE                    ProcessorMaxThrottle;
            public byte FastSystemS4;                       //   BOOLEAN                 FastSystemS4;
            public byte Hiberboot;                          //   BOOLEAN                 HiberBoot;
            public byte WakeAlarmPresent;                   //   BOOLEAN                 WakeAlarmPresent;
            public byte AoAc;                               //   BOOLEAN                 AoAc;

                                                            //   // Disk
            public byte DiskSpinDown;                       //   BOOLEAN                 DiskSpinDown;

                                                            //   // HiberFile
            public byte HiberFileType;                      //   BYTE                    spare3[8];
            public byte AoAcConnectivitySupported;          //
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
            public byte[] spare3;

                                                            //   // System Battery
            public byte SystemBatteriesPresent;             //   BOOLEAN                 SystemBatteriesPresent;
            public byte BatteriesAreShortTerm;              //   BOOLEAN                 BatteriesAreShortTerm;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public BATTERY_REPORTING_SCALE[]  BatteryScale; //   BATTERY_REPORTING_SCALE BatteryScale[3];

                                                            //   // Wake
            public SYSTEM_POWER_STATE AcOnLineWake;         //   SYSTEM_POWER_STATE      AcOnLineWake;
            public SYSTEM_POWER_STATE SoftLidWake;          //   SYSTEM_POWER_STATE      SoftLidWake;
            public SYSTEM_POWER_STATE RtcWake;              //   SYSTEM_POWER_STATE      RtcWake;
            public SYSTEM_POWER_STATE MinDeviceWakeState;   //   SYSTEM_POWER_STATE      MinDeviceWakeState;
            public SYSTEM_POWER_STATE DefaultLowLatencyWake;//   SYSTEM_POWER_STATE      DefaultLowLatencyWake;
                                                            // } SYSTEM_POWER_CAPABILITIES, *PSYSTEM_POWER_CAPABILITIES;
        }

        [System.Runtime.InteropServices.DllImport("PowrProf.dll")]
        static extern bool GetPwrCapabilities(out SYSTEM_POWER_CAPABILITIES rf);

        public NtPowerCall()
        {
            bool _blRetVal = false;

            _blRetVal = _pfnGetPwrCapabilities();
        }

        public static bool classInitialized;
        public static SYSTEM_POWER_CAPABILITIES SystemPowerCapabilities;

        static bool _pfnGetPwrCapabilities()
        {
            bool _blRetVal = false;
            SYSTEM_POWER_CAPABILITIES _Data;

            try
            {
                _blRetVal = GetPwrCapabilities(out _Data);
                SystemPowerCapabilities = _Data;
                classInitialized = true;
            } catch {
            }


            return (_blRetVal);
        }


    } // End -- NtPowerCall Class

    public class Kernel32DllCall
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        static extern bool Wow64DisableWow64FsRedirection( out int OldValue );

        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        static extern bool Wow64RevertWow64FsRedirection( int OldValue );

        public static int      ptrWow64OldValue;
        public static bool     blValid_Wow64OldValue;

        public Kernel32DllCall()
        {
            // Initialize for the class member(s)
            blValid_Wow64OldValue = false;
        }

        // Public Functions for PowerShell
        public bool dll_DisableWow64FsRedirection()
        {
            bool _blRetVal = false;

            if( blValid_Wow64OldValue == false ){
                _blRetVal = Wow64DisableWow64FsRedirection( out ptrWow64OldValue );
                if( _blRetVal != false ){
                    blValid_Wow64OldValue = true;
                }            
            } else {
                _blRetVal = true;
            }

            return( _blRetVal );
        }

        public bool dll_RevertWow64FsRedirection()
        {
            bool _blRetVal = false;
            if( blValid_Wow64OldValue != false ){
                _blRetVal = Wow64RevertWow64FsRedirection( ptrWow64OldValue );
                if( _blRetVal != false ){
                    blValid_Wow64OldValue = false;
                }
            } else {
                _blRetVal = true;
            }              

            return( _blRetVal );
        }


    } // End -- Kernel32DllCall Class
}

'@

$SysPwrCaps = New-Object -TypeName DynaLoadAPI.NtPowerCall
$Kern32Dll  = New-Object -TypeName DynaLoadAPI.Kernel32DllCall

function DisableWow64FsRedirection
{
    if( $Kern32Dll ){
        $blRetVal = $Kern32Dll.dll_DisableWow64FsRedirection();
    }

} # EOF

function RevertWow64FsRedirection
{
    if( $Kern32Dll ){
        $blRetVal = $Kern32Dll.dll_RevertWow64FsRedirection();
    }

} # EOF

Export-ModuleMember -Function DisableWow64FsRedirection
Export-ModuleMember -Function RevertWow64FsRedirection

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBKBQemK1nSeXVP
# LTqiXx67e1JHbQks6M0E2jK/2v2Xg6CCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQgNzbr1Wku
# TM7WcAutIegWLozzXQkh3heSjESbBnqgvhQwDQYJKoZIhvcNAQEBBQAEggEASfX8
# lbnVkD4Fqm/7vu80An9uTAw/DdAeXGoMG0gjQFpHIvI9wrwro3gFg5ml7o645GXb
# V5IuBi7dJmWEnpKPJpLqBpCxiv4cjDGfLJkA0cZbKSz6F7Oo3jHEOlCRqgBHbGN8
# R94Dk/bgO/YIucaZC0vjgV72AqSTPy6P6WCUPhimLae6VSggWEsqcsF0s6bzJoFT
# 1iowAiQuYT/ys4KXxi1cADWqZctWc9m43/sf8pKUf+aBrdap2lTz3ntUUcWYaR5a
# LaCNg/Vfim0WlnK7JA6QafeC+77JQQ/MY/8H+I151R00MSeN+i9VCaQYbx2IdZL0
# 76NhUA/Q4E0ykpqB7A==
# SIG # End signature block
