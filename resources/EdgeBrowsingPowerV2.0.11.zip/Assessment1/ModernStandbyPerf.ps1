<#
.SYNOPSIS
    Modern Standby Performance Assessment

.DESCRIPTION
    Automates Modern Standby power transitions and measures entry/exit latency metrics

.PARAMETER iterations
    Number of Modern Standby transitions to automate
.PARAMETER sleeptimeout_sec
    Duration in seconds of the Modern Standby session
.PARAMETER postdelay_sec
    Delay in seconds between iterations
.PARAMETER NetworkingState
    Disconnected standby
.PARAMETER disablequiethours
    Disable the OS Quiet Hours feature before entering Modern Standby
.PARAMETER modeaggressive
    Enable aggressive mode during disconnected standby
.PARAMETER simulatedbatteries
    Simulate batteries without unplugging the AC power
.PARAMETER enablepowerlogs
    Select to gather additional power related log files for diagnostics
.PARAMETER enablehellologs
    Select to gather additional hello related log files for diagnostics
.PARAMETER traceprofile
    Alternate WPRP tracing profile
.PARAMETER DebugFlag
    Pause at the end of the script to allow diagnostics of console output
.PARAMETER ConfigJson
    Alternate JSON configuration file
#>
Param( 
    [parameter(Mandatory=$false)][int32]$iterations,
    [parameter(Mandatory=$false)][int32]$sleeptimeout_sec,
    [parameter(Mandatory=$false)][int32]$postdelay_sec,
    [parameter(Mandatory=$false)][int32]$NetworkingState,
    [parameter(Mandatory=$false)][switch]$disablequiethours,
    [parameter(Mandatory=$false)][switch]$modeaggressive,
    [parameter(Mandatory=$false)][switch]$simulatedbatteries,
    [parameter(Mandatory=$false)][switch]$enablepowerlogs,
    [parameter(Mandatory=$false)][switch]$enablehellologs,
    [parameter(Mandatory=$false)][string]$traceprofile,
    [parameter(Mandatory=$false)][switch]$DebugFlag,
    [parameter(Mandatory=$false)][switch]$DirtyModernStandby,
    [parameter(Mandatory=$false)][switch]$EnableLockScreen,
    [parameter(Mandatory=$false)][switch]$EnablePinAutomation,
    [parameter(Mandatory=$false)][string]$UserName,
    [parameter(Mandatory=$false)][string]$PIN,
    [parameter(Mandatory=$true)][string]$ConfigJson,
    [parameter(Mandatory=$false)][switch]$EnableStressTest
)
try
{
    $SimBattInstalled = $false
    $SimBattDisableRealBatteries = $false
    $SimBattToDC = $false

    # Need to know where our script is so we can use full path to all our dependent files.
    $InvocationPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
    $AxeUniversalPath = Convert-Path((Get-Item env:\AssessmentAxeUniversalPath).value)
	
    try
    {
        # Import the modules and functions
        Import-Module "$AxeUniversalPath\UniversalAssessment.psm1" -ErrorAction Stop
    }
    catch
    {
        throw "Failed to import $AxeUniversalPath\UniversalAssessment.psm1"
    }
    Initialize-UniversalFramework -InvocationPath (Split-Path -Path $MyInvocation.MyCommand.Path -Parent) -AxeUniversalPath $AxeUniversalPath

    # Configuration JSON file
    try {
        $IniJSON =  Get-Content -Raw -Path $ConfigJson | ConvertFrom-Json
    }
    catch {
        Throw "Unable to load JSON config file ($ConfigJson)"
    }

    #subfolders
    $ModulesPath = Join-Path -path $InvocationPath modules
	
    #Import AXE support helper module
    Import-Module "$ModulesPath\CommonSystem.psm1" -ErrorAction Stop

    #Import simulate batteries module
    Import-Module "$ModulesPath\SimBattPSHelper.psm1" -ErrorAction Stop

    # Import power logs helper module
    Import-Module "$ModulesPath\PowerLogsPSHelper.psm1" -ErrorAction Stop

    # Import powercfg helper module
    Import-Module "$ModulesPath\PowerCfgPSHelper.psm1" -ErrorAction Stop

    # Tools and resources
    $realarch              = Get-RealProcessorArchitecture

    $powershellArch  = Get-PowerShellArchitecture
    if ($powershellArch -eq "arm64") {
        $powershellArch = "amd64"
    }
    $InvocationArch  = Join-Path -path $InvocationPath $powershellArch
    $env:path        = "$InvocationArch;" + "$InvocationPath;" + $env:path

    $StabDelay = $IniJSON.Execution.StabilizationDelaySec

    # Path for process execution logs (err and std outputs)
    $LogsPath = join-path -path $AXEResultsPath logs
    if (-not (test-path $LogsPath))
    {
        New-Item $LogsPath -ItemType directory > $null
    }

    if ($EnablePinAutomation)
    {
        $credentialsJsonFile = "$InvocationPath\credentials.json"
        Update-UserNameAndPINFromJson -credentialsJsonFile $credentialsJsonFile -UserName ([ref]$UserName) -PIN ([ref]$PIN)

        [string[]]$CustomPackages = @("Microsoft-Assessments-Core-LogonUXAutomation.cab")
        Install-UT_TaefPackages -arch $realarch -CabsPath $AxeCabsPath -BinariesPath $BinariesPath -CustomPackages $CustomPackages
    }
    
    if ($EnableStressTest)
    {
        [string[]]$CustomPackages = @("Microsoft-Assessments-Core-Session0Launcher.cab")
        Install-UT_TaefPackages -arch $realarch -CabsPath $AxeCabsPath -BinariesPath $BinariesPath -CustomPackages $CustomPackages
    }


    ######################################
    #
    #   Execution
    #
    ######################################

    if ($DirtyModernStandby)
    {
        $idAmazon = Start-Process -FilePath https://www.amazon.com -PassThru
        start-sleep -Seconds 1
        Start-Process -FilePath https://youtu.be/16mHR2wHiwI?t=1
        start-sleep -Seconds 1
        Start-Process -FilePath https://en.wikipedia.org/wiki/United_States
        start-sleep -Seconds 1
        
        $MailApp = ((New-Object -ComObject Shell.Application).NameSpace("shell:appsfolder").Items() | Where-Object { $_.Name -eq "Mail"})
        if ($MailApp -ne $null)
        {
            explorer shell:AppsFolder\$($MailApp.Path)
        }
        else
        {
            "WARNING: Unable to find Mail app for DirtyModernStandby option" | Log-Info
        }
    }
    
    try
    {
        if ($simulatedbatteries)
        {
            # change directory to make SimBattCtl.exe happy
            Set-Location -Path "$InvocationPath\$realarch"
            # Install simulated batteries
            "Install simulated batteries" | Log-Info
            Invoke-SimBattCtl -StageMessage "Install simulated batteries" `
                -Option "-i" -LogsPath "$LogsPath"
            $SimBattInstalled = $true

            # Disable all real batteries
            "Disable all real batteries" | Log-Info
            Invoke-SimBattCtl -StageMessage "Disable all real batteries" `
                -Option "-x" -LogsPath "$LogsPath"
            $SimBattDisableRealBatteries = $true

            # Set simulated batteries to DC power
            "Set simulated batteries to DC power" | Log-Info
            Invoke-SimBattCtl -StageMessage "Set simulated batteries to DC power" `
                -Option "-d" -LogsPath "$LogsPath"
            $SimBattToDC = $true
        }

        "Sleeping $StabDelay seconds for stabilization" | Log-Info 
        start-sleep -Seconds $StabDelay

        # Launch the ConnectedStandby automation binary
        "Launching ModernStandby automation for $iterations iterations" | Log-Info
        Start-Process "$InvocationPath\$realarch\ConnectedStandby.exe" `
            -ArgumentList "/sleeptimeout_sec $sleeptimeout_sec /iterations $iterations /postonoffsec $postdelay_sec /NetworkingState $NetworkingState /resultspath `"$AXEResultsPath`" /axebinpath `"$env:AssessmentAxeBinPath`" $(if($disablequiethours) {"/disablequiethours"}) $(if($modeaggressive) {"/modeaggressive"}) $(if($enablehellologs) {"/enablehellologs"}) $(if($EnableLockScreen) {"/EnableLockScreen"}) $(if($EnablePinAutomation) {"/EnablePinAutomation /UserName $UserName /PIN $PIN"}) $(if($EnableStressTest) {"/EnableStressTest"})" `
            -Wait `
            -RedirectStandardError "$LogsPath\ms_timing_err.txt" `
            -RedirectStandardOutput "$LogsPath\ms_timing_std.txt" `
            -NoNewWindow
        
        # add Regions of Interest XML file in the JobResults folder
        $ResourcesPath = Join-Path -path $InvocationPath resources
        Copy-Item $ResourcesPath\ModernStandby.Regions.xml $AXEResultsPath -Force
        Copy-Item $ResourcesPath\ModernStandby.wpaProfile $AXEResultsPath -Force
    }
    catch
    {
        throw
    }
    finally
    {
        # Uninstall simulated batteries before starting power logs to avoid
        # uninstallation (of simulated batteries) failure
        if ($SimBattToDC)
        {
            # Set simulated batteries to AC power
            "Set simulated batteries to AC power" | Log-Info
            $err = Invoke-SimBattCtl -StageMessage "Set simulated batteries to AC power" `
                -Option "-a" -LogsPath "$LogsPath" `
                -ThrowOnError $false
            if ($err.length -ne 0)
            {
                "$err" | Log-Info
            }
        }

        if ($SimBattDisableRealBatteries)
        {
            # Enable all real batteries
            "Enable all real batteries" | Log-Info
            $err = Invoke-SimBattCtl -StageMessage "Enable all real batteries" `
                -Option "-e" -LogsPath "$LogsPath" `
                -ThrowOnError $false
            if ($err.length -ne 0)
            {
                "$err" | Log-Info
            }
        }

        if ($SimBattInstalled)
        {
            # Uninstall simulated batteries
            "Uninstall simulated batteries" | Log-Info
            $err = Invoke-SimBattCtl -StageMessage "Uninstall simulated batteries" `
                -Option "-u" -LogsPath "$LogsPath" `
                -ThrowOnError $false
            if ($err.length -ne 0)
            {
                "$err" | Log-Info
            }
        }
    }
    
    if ($DirtyModernStandby)
    {
        # Stop-Process -Id $idAmazon.Id
        Get-Process "*Outlook*" | Stop-Process -force
        Get-Process "*msedge*" | Stop-Process -force
    }

    # Enable power logs
    if ($enablepowerlogs)
    {
        "Start Power Logs" | Log-Info
        # Path for power logs
        $PowerLogsPath = join-path -path $AXEResultsPath powerlogs
        if (-not (Test-Path "$PowerLogsPath" -pathType container))
        {
            New-Item $PowerLogsPath -ItemType directory > $null
        }
        $_cmdletExist = Get-Command DisableWow64FsRedirection; if ( $_cmdletExist ) { DisableWow64FsRedirection };
        Start-PowerLogs -PowerLogsPath $PowerLogsPath
        $_cmdletExist = Get-Command RevertWow64FsRedirection ; if ( $_cmdletExist ) { RevertWow64FsRedirection };
    }
}
catch
{
    Handle-UniversalFrameworkException -Exception $_
}
finally 
{
    try
    {
        "Generating system power report..." | Log-Info
        Write-PowerConfigSystemPowerReport -ResultPath $AXEResultsPath
    }
    catch
    {
        $_ | Out-AxeError $_.Exception.Hresult
        $message = $_.Exception.Message + [Environment]::NewLine + $_.InvocationInfo.PositionMessage
        $message | Log-Info
    }

    # We should always properly dispose of this guy.
    #
    "Cleanup..." | Log-Info
    Cleanup-UniversalFramework
}

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCbkwDA79aPQx8U
# RgJu0lCsd6w+i9h1IeBeY3rzwg4t6KCCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQgzZHc1qtI
# tOzDDrvd54k5+2Fbe+ejbaqQScM0RCtC8t4wDQYJKoZIhvcNAQEBBQAEggEAuWc7
# qlC9gVmyw+3w9Ijkzeh4/j9Sc7k98rtFceO8YSFzzO1mi0JadPj0e6hPCqt3tGLC
# EA+Ypxia+NDEKTPnE3VJDHQ4F282SXLS5WWtkwFw1eI9a7Jh0fGr1IVICU7P3IZw
# XCvudLy0NR2PW1lr7g0YbmGkVdpWhRIgsxvGnH6ndzIVGGVf684jkkpTU1KOSyKF
# 1KWG5gFqbvSKXJzQG6ZWCGxsWsmdf//RXX6alz0uzX1fzsiBFp51IKDuxyZCpr9u
# ThxHj//iZH3wysBrz/m+jmGDNomn//znvtccNh4+z/oZDuN4T3DcOpfNYAvnKH3h
# jtXbFReAPUzTtA6U2A==
# SIG # End signature block
