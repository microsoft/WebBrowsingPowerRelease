﻿<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:powercfg="http://schemas.microsoft.com/energy/2007"
                exclude-result-prefixes="powercfg"
                version="1.0">
    <!--xmlns:n1="http://schemas.microsoft.com/energy/2007"-->

    <xsl:output method="xml" indent="yes" />
    <xsl:template match="/">
        <AssessmentResult>
            <Iterations>
                <Iteration>
                    <Ordinal>0</Ordinal>
                    <MetricValues>
                        <!-- [powercfg.exe /energy] Metric #1 Availability Request Count-->
                        <MetricValue>
                            <xsl:if test="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='d6f4a3bd-f55a-45ef-a705-640cfbb24f42']">
                                <ProgrammaticName>AvailabilityRequestCount</ProgrammaticName>
                                <Value><xsl:value-of select="count(/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='d6f4a3bd-f55a-45ef-a705-640cfbb24f42']/powercfg:AnalysisLog/powercfg:LogEntry[powercfg:Severity!='Informational'])" /></Value>
                            </xsl:if>
                        </MetricValue>
                        <!-- [powercfg.exe /energy] Metric #2 System Timer Resolution -->
                        <MetricValue>
                            <ProgrammaticName>SystemTimerResolution</ProgrammaticName>
                            <Value>
                                <xsl:if test="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='374923cf-cc7f-4b12-b22b-ef4652df2f2d']/powercfg:Severity='Warning'">
                                    <xsl:value-of select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry/powercfg:Details/powercfg:Detail[@guid='b69a821d-f468-4016-b1cb-3e8433aca246']/powercfg:Value div 10000" />
                                </xsl:if>
                                <xsl:if test="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='843c944e-9fc2-4e58-9e58-9bfdf0ea25b2']/powercfg:Severity='Informational'">
                                    <xsl:value-of select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry/powercfg:Details/powercfg:Detail[@guid='e5ba7e97-57dd-4378-a022-0b5b3fff3d22']/powercfg:Value div 10000" />
                                </xsl:if>
                            </Value>
                        </MetricValue>
                        <!-- [powercfg.exe /energy] Metric #3  Processes Changing System Timer -->
                        <MetricValue>
                            <ProgrammaticName>ProcessesChangingSystemTimerResolution</ProgrammaticName>
                            <Value><xsl:value-of select="count(/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='436954b1-cc2d-4740-9f97-23d1f2c1210e'])" /></Value>
                        </MetricValue>
                        <!-- [powercfg.exe /energy] Metric # 4 USB Selective Suspend Issues-->
                        <MetricValue>
                            <ProgrammaticName>USBSelectiveSuspendIssues</ProgrammaticName>
                            <Value><xsl:value-of select="count(/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='5a462902-896e-4fbb-a3f2-db2a5b3fc583']/powercfg:AnalysisLog/powercfg:LogEntry[@guid!='326fb9d3-85d4-4975-a922-f74e71c12360'])" /></Value>
                        </MetricValue>
                        <!-- [powercfg.exe /energy] Metric # 5 Power Policy Configuration Errors-->
                        <MetricValue>
                            <ProgrammaticName>PowerPolicyConfigurationErrors</ProgrammaticName>
                            <Value><xsl:value-of select="count(/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='468e6809-1940-4b2d-ae6c-2208ad6e196b']/powercfg:AnalysisLog/powercfg:LogEntry[(@guid!='fc79a03c-7f75-45db-b4df-c5582adbe2a5' and @guid!='fc72f15c-ba05-49c0-b387-8cff36675ae5') and powercfg:Severity='Error'])" /></Value>
                        </MetricValue>
                        <!-- [powercfg.exe /energy] Metric # 6 Power Policy Configuration Warnings-->
                        <MetricValue>
                            <ProgrammaticName>PowerPolicyConfigurationWarnings</ProgrammaticName>
                            <Value><xsl:value-of select="count(/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='468e6809-1940-4b2d-ae6c-2208ad6e196b']/powercfg:AnalysisLog/powercfg:LogEntry[powercfg:Severity='Warning'])" /></Value>
                        </MetricValue>
                    </MetricValues>
                    <!--  **********************************************-->
                    <!--          THIS IS THE START OF Thresholds       -->
                    <!--  **********************************************-->
                    <MetricThresholds>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>AvailabilityRequestCountThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>AvailabilityRequestCount</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>AvailabilityRequestCountThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>SystemTimerResolutionThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>SystemTimerResolution</MetricDefinitionProgrammaticName>
                            <Target>15.6</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>SystemTimerResolutionThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Double/>
                                    </ValueType>
                                    <Value>15.6</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>ProcessesChangingSystemTimerResolutionThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>ProcessesChangingSystemTimerResolution</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>ProcessesChangingSystemTimerResolutionThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>USBSelectiveSuspendIssuesThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>USBSelectiveSuspendIssues</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>USBSelectiveSuspendIssuesThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>PowerPolicyConfigurationErrorsThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>PowerPolicyConfigurationErrors</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PowerPolicyConfigurationErrorsThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>PowerPolicyConfigurationWarningsThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>PowerPolicyConfigurationWarnings</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PowerPolicyConfigurationWarningsThresholdWarnValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PowerPolicyConfigurationWarningsThresholdFailValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>20</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>ActiveC-StateResidencyThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>ActiveC-StateResidency</MetricDefinitionProgrammaticName>
                            <Target>2</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>ActiveC-StateResidencyThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Double/>
                                    </ValueType>
                                    <Value>0.5</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>DeepC-StateResidencyThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>DeepC-StateResidency</MetricDefinitionProgrammaticName>
                            <Target>98</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>DeepC-StateResidencyThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Double/>
                                    </ValueType>
                                    <Value>99</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>PeriodicCPUSourcesLessThan100msThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>PeriodicCPUSourcesLessThan100ms</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PeriodicCPUSourcesLessThan100msThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>PeriodicCPUSourcesLessThan300msThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>PeriodicCPUSourcesLessThan300ms</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PeriodicCPUSourcesLessThan300msThresholdWarnValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PeriodicCPUSourcesLessThan300msThresholdFailValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>100</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>ProcessesUtilizingGreaterThan1PercentCPUThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>ProcessesUtilizingGreaterThan1PercentCPU</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>ProcessesUtilizingGreaterThan1PercentCPUThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>DiskReadKiloBytesThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>DiskReadKiloBytes</MetricDefinitionProgrammaticName>
                            <Target>5</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>DiskReadKiloBytesThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Double/>
                                    </ValueType>
                                    <Value>5</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>DiskReadCountThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>DiskReadCount</MetricDefinitionProgrammaticName>
                            <Target>200</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>DiskReadCountThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>200</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>DiskFlushCountThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>DiskFlushCount</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>DiskFlushCountThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                        <MetricThreshold>
                            <Description>
                                <ProgrammaticName>PeriodicDiskSourcesLessThan10mThreshold</ProgrammaticName>
                            </Description>
                            <MetricDefinitionProgrammaticName>PeriodicDiskSourcesLessThan10m</MetricDefinitionProgrammaticName>
                            <Target>0</Target>
                            <MetricThresholdValues>
                                <MetricThresholdValue>
                                    <Description>
                                        <ProgrammaticName>PeriodicDiskSourcesLessThan10mThresholdValue</ProgrammaticName>
                                    </Description>
                                    <ValueType>
                                        <Int32/>
                                    </ValueType>
                                    <Value>0</Value>
                                    <Comparison>
                                        <Absolute />
                                    </Comparison>
                                    <Inclusion>
                                        <Inclusive />
                                    </Inclusion>
                                </MetricThresholdValue>
                            </MetricThresholdValues>
                        </MetricThreshold>
                    </MetricThresholds>

                    <!--  **********************************************-->
                    <!--          THIS IS THE START OF ISSUES           -->
                    <!--  **********************************************-->
                    <Issues>
                        <!-- [powercfg.exe /energy] Issue #3 Power Policy Configuration Errors-->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='468e6809-1940-4b2d-ae6c-2208ad6e196b']/powercfg:AnalysisLog/powercfg:LogEntry[(@guid!='fc79a03c-7f75-45db-b4df-c5582adbe2a5' and @guid!='fc72f15c-ba05-49c0-b387-8cff36675ae5') and powercfg:Severity='Error']">
                            <Issue ID="0" Known="No">
                                <IssueTitle><xsl:value-of select="powercfg:Name" /></IssueTitle>
                                <IssueDescription><xsl:value-of select="powercfg:Description" /></IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>PowerPolicyConfigurationErrors</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Adjust your power policy.</Description>
                                </Solution>
                                <Impact Severity="0">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <!-- [powercfg.exe /energy] Issue #4 Power Policy Configuration Warnings-->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='468e6809-1940-4b2d-ae6c-2208ad6e196b']/powercfg:AnalysisLog/powercfg:LogEntry[powercfg:Severity='Warning']">
                            <Issue ID="0" Known="No">
                                <IssueTitle><xsl:value-of select="powercfg:Name" /></IssueTitle>
                                <IssueDescription><xsl:value-of select="powercfg:Description" /></IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>PowerPolicyConfigurationWarnings</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Adjust your power policy.</Description>
                                </Solution>
                                <Impact Severity="1">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <!-- [powercfg.exe /energy] Issue #7 System Timer Resolution -->
                        <xsl:if test="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='374923cf-cc7f-4b12-b22b-ef4652df2f2d']/powercfg:Severity='Warning'">
                            <Issue ID="0" Known="No">
                                <IssueTitle>System Timer Resolution</IssueTitle>
                                <IssueDescription>The system timer resolution was <xsl:value-of select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry/powercfg:Details/powercfg:Detail[@guid='b69a821d-f468-4016-b1cb-3e8433aca246']/powercfg:Value div 10000" /> ms. The default is  <xsl:value-of select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry/powercfg:Details/powercfg:Detail[@guid='69ba80f7-7254-43ee-b20d-4da5a0826d9f']/powercfg:Value div 10000" /> ms. Changes to the system timer resolution may increase power consumption.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>SystemTimerResolution</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>CPU Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Investigate processes that change the system timer resolution.</Description>
                                </Solution>
                                <Impact Severity="0">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:if>

                        <!-- [powercfg.exe /energy] Issue #11 USB Selective Suspend-->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='5a462902-896e-4fbb-a3f2-db2a5b3fc583']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='109f745a-2d80-4358-b63a-0c7a2ae1afea']">
                            <Issue ID="0" Known="No">
                                <IssueTitle>USB Selective Suspend</IssueTitle>
                                <IssueDescription>The USB Device "<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='20e05e87-f844-47bf-ba24-61c9f4352443']/powercfg:Value" />" with device ID "<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='593d5629-32b8-479e-8c5d-ab887bc96632']/powercfg:Value" />" and host controller "<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='a38be980-89fa-4b54-af1b-4e164e7fcaa3']/powercfg:Value" />" did not enter the selective suspend state. USB devices that do not enter selective suspend will reduce energy efficiency. Note, that a host controller will not be able to enter a low power state if an attached device did not enter selective suspend.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>USBSelectiveSuspendIssues</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Investigate the specified device, host controller, and attached devices for issues preventing them from entering the selective suspend state.</Description>
                                </Solution>
                                <Impact Severity="0">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='5a462902-896e-4fbb-a3f2-db2a5b3fc583']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='9bf95c2b-e480-4443-9c1a-8ca89487a760']">
                            <Issue ID="0" Known="No">
                                <IssueTitle>USB Selective Suspend</IssueTitle>
                                <IssueDescription>The USB Device "<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='8c79ad5a-ff8e-4fef-921a-469044ce210c']/powercfg:Value" />" with device ID "<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='edb81401-d290-40ed-92d1-1b9459d96a95']/powercfg:Value" />" and host controller "<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='a0727ebb-47f6-4ba6-b45e-360d67076c9a']/powercfg:Value" />" intermittently enters and exits the USB Selective Suspend state. Processor power management may be prevented when this USB device is not in the Selective Suspend state.Note, that a host controller will not be able to enter a low power state if an attached device did not enter selective suspend.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>USBSelectiveSuspendIssues</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Investigate the specified device, host controller, and attached devices for issues preventing them from entering the selective suspend state.</Description>
                                </Solution>
                                <Impact Severity="1">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <!-- [powercfg.exe /energy] Issue #12 Display Availability Request -->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='d6f4a3bd-f55a-45ef-a705-640cfbb24f42']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='efc02519-ec94-4e1d-b237-b7e3b9bd5bb0']" >
                            <Issue ID="0" Known="No">
                                <IssueTitle>Display Availability Request</IssueTitle>
                                <IssueDescription>The <xsl:value-of select="powercfg:Details/powercfg:Detail/Name"/> "<xsl:value-of select="powercfg:Details/powercfg:Detail/powercfg:Value"/>" made a display availability request, preventing the system from automatically powering off the display and conserving energy.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>AvailabilityRequestCount</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Consider updating this component and running the assessment again. If the issue remains and this is not a required or a system component, consider removing it or preventing it from making the request by using the powercfg /requestsoverride command.</Description>
                                </Solution>
                                <Impact Severity="1">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <!-- [powercfg.exe /energy] Issue #13 System Required Request  -->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='d6f4a3bd-f55a-45ef-a705-640cfbb24f42']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='6ddf5fb2-1250-4f4d-adb2-9d7274be8617' or @guid='1b85ad61-a64f-43bf-a1fd-ee4431c5e4a4' or @guid='6a71b74c-ee64-4991-9b84-8f7c71f1421f' or @guid='c4515652-871e-415b-8fc3-c50d1fb152d4' or @guid='da5d1fec-20d6-4566-9455-ee50c597c1ff']" >
                            <Issue ID="0" Known="No">
                                <IssueTitle>System Availability Request</IssueTitle>
                                <IssueDescription>The <xsl:value-of select="powercfg:Details/powercfg:Detail/powercfg:Name"/> "<xsl:value-of select="powercfg:Details/powercfg:Detail/powercfg:Value"/>" made a system availability request, preventing the system from entering a low-power state and conserving energy.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>AvailabilityRequestCount</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Consider updating this component and running the assessment again. If the issue remains and this is not a required or a system component, consider removing it or preventing it from making the request by using the powercfg /requestsoverride command.</Description>
                                </Solution>
                                <Impact Severity="0">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <!-- [powercfg.exe /energy] Issue #14 Away Mode Request  -->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='d6f4a3bd-f55a-45ef-a705-640cfbb24f42']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='3afb2805-511c-4313-93ea-fda1b9ba3972' or  @guid='92814dcf-1e4c-4d51-a306-86248e2ededf']" >
                            <Issue ID="0" Known="No">
                                <IssueTitle>Ayway Mode Request</IssueTitle>
                                <IssueDescription>The <xsl:value-of select="powercfg:Details/powercfg:Detail/Name"/> "<xsl:value-of select="powercfgDetails/powercfg:Detail/powercfg:Value"/>" made an away mode availability request, preventing the system from entering a low-power state and conserving energy.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>AvailabilityRequestCount</MetricReference>
                                </AffectedMetrics>
                                <Solution>
                                    <Description>Consider updating this component and running the assessment again. If the issue remains and this is not a required or a system component, consider removing it or preventing it from making the request by using the powercfg /requestsoverride command.</Description>
                                </Solution>
                                <Categories>
                                    <Category>Other Energy Efficiency Issues</Category>
                                </Categories>
                                <Impact Severity="1">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>

                        <!-- [powercfg.exe /energy] Issue #20 Process Timer Resolution-->
                        <xsl:for-each select="/powercfg:EnergyReport/powercfg:Troubleshooter[@guid='b80a1fd9-c81e-479f-8f72-c6a1e9e54dec']/powercfg:AnalysisLog/powercfg:LogEntry[@guid='436954b1-cc2d-4740-9f97-23d1f2c1210e']">
                            <Issue ID="0" Known="No">
                                <IssueTitle>Process Changed Timer Resolution</IssueTitle>
                                <IssueDescription><xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='d08924ce-6dac-46b4-80c2-4ece748e059c']/powercfg:Value" /> (<xsl:value-of select="powercfg:Details/powercfg:Detail[@guid='0ce5eb38-d897-4749-8210-242e77718472']/powercfg:Value" />) requested a change in system timer resolution. Changes to the system timer resolution may increase power consumption.</IssueDescription>
                                <AffectedMetrics>
                                    <MetricReference>ProcessesChangingSystemTimerResolution</MetricReference>
                                </AffectedMetrics>
                                <Categories>
                                    <Category>CPU Energy Efficiency Issues</Category>
                                </Categories>
                                <Solution>
                                    <Description>Consider updating this component and running the assessment again. If the issue remains and this is not a required or a system component, consider removing it.</Description>
                                </Solution>
                                <Impact Severity="0">
                                    <RelatedActivities/>
                                </Impact>
                                <AnalysisLinks>
                                    <Link>
                                        <LinkTitle>Power Configuration HTML Report</LinkTitle>
                                        <LinkToolTip>Refer to the power configuration report for more information.</LinkToolTip>
                                        <LinkURI>file://[AssessmentExecutionPath]\PowerConfig\PowerCfg-EnergyReport.html</LinkURI>
                                    </Link>
                                </AnalysisLinks>
                            </Issue>
                        </xsl:for-each>
                    </Issues>
                </Iteration>
            </Iterations>
        </AssessmentResult>
    </xsl:template>
</xsl:stylesheet>
