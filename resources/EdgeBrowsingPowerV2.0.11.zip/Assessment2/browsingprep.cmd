for %%d in (%~dp0..) do set ParentDir=%%~fd
REM %ParentDir%\%PROCESSOR_ARCHITECTURE% might contains spaces so enclosed with "'".
start "" /MIN %~dp0%PROCESSOR_ARCHITECTURE%\EdgeAutomationHost.exe /AxeBinPath '%ParentDir%\%PROCESSOR_ARCHITECTURE%' /BrowsingProfile scenario.browsing.json /Debug /Mode training /TextLogOutput adk\BrowsingPrepLog.txt