<#
    .SYNOPSIS
    Multiple Join Performance Assessment

    .DESCRIPTION
    Multiple Presons Join Teams Meeting.

    .PARAMETER ScenarioDurationMins
    Integer, execution duraion in minutes for a scenario

    .EXAMPLE
    MultipleJoin -BrowsingProfile scenario.teams_multiple_join_meeting.json
                 -$MeetingInvitationUrl "https://teams.live.com/meet/95144127751892"
                 -JoinPersons 9 -MultipleJoinWait 25
                 -ScenarioDurationMins 2000
#>

Param(
    [parameter(Mandatory = $true)]
    [string]
    $BrowsingProfile = '',

    [parameter(Mandatory = $true)]
    [string]
    $MeetingInvitationUrl = '',

    [parameter(Mandatory = $true)]
    [int32]
    $JoinPersons = 9,

    [parameter(Mandatory = $true)]
    [int32]
    $MultipleJoinWait = 25,

    [parameter(Mandatory = $true)]
    [int32]
    $ScenarioDurationMins = 2000,

    [parameter(Mandatory = $false)]
    [string]
    $TextLogOutput = $null
)

# Exit $exitCode will not affect the real return code but it will affect return code 0 ($exitCode == 0) or 1 ($exitCode != 0) no matter run by powershell.exe -Command or -File.
$exitCode = 0
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

New-Variable -Name TestExe -Value "EdgeAutomationHost.exe" -Option Constant

try
{
    #*****************************************************************
    #
    #                Definitions and imports
    #
    #*****************************************************************

    #set to true if you need to hang the script at the end to check console output
    $Global:debugFlag = $false

    # Tools and resources
    $Global:AxeUniversalPath = Convert-Path((Get-Item env:\AssessmentAxeUniversalPath -ErrorAction Stop).value)
    $Global:InvocationPath   = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

    try
    {
        # Import the modules and functions
        Import-Module "$AxeUniversalPath\UniversalAssessment.psm1" -ErrorAction Stop
    }
    catch
    {
        $exitCode = 100
        throw "[Amst-<WinAppAutomation>][ExecuteWorkload]Failed to import $AxeUniversalPath\UniversalAssessment.psm1"
    }

    Initialize-UniversalFramework -InvocationPath $InvocationPath -AxeUniversalPath $AxeUniversalPath

    $teArgs = ""
    $teArgs += " /BrowsingProfile $BrowsingProfile"

    if ($TextLogOutput)
    {
        $teArgs += " /TextLogOutput `"$TextLogOutput`""
    }

    #
    # JSON scenario parameters
    #
    if ($MeetingInvitationUrl)
    {
        $teArgs += " /json.MeetingInvitationUrl `"$MeetingInvitationUrl`""
    }

    $teArgs += " /json.JoinPersons `"$JoinPersons`""
    $teArgs += " /json.MultipleJoinWait `"$MultipleJoinWait`""
    $teArgs += " /InPrivate"

    if ($ScenarioDurationMins)
    {
        $ScenarioDurationSecs = $ScenarioDurationMins * 60
        $teArgs += " /json.ScenarioDurationSecs `"$ScenarioDurationSecs`""
    }

    "Start $TestExe $teArgs." | Log-Info
    $proc = Start-Process $Global:InvocationPath\$(Get-RealProcessorArchitecture)\$TestExe -ArgumentList $teArgs -PassThru -WindowStyle Minimized
    $handle = $proc.Handle # cache proc.Handle
    $proc.WaitForExit();
    $exitCode = $proc.ExitCode

    if ($exitCode -ne 0)
    {
        throw ("[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]EdgeAutomationHost.exe exited with errors LastExitCode:{0}" -f $exitCode)
    }
    "$TestExe $teArgs is done." | Log-Info

    Start-Sleep 5
}
catch
{
    Handle-UniversalFrameworkException -Exception $_
}
finally
{
    Cleanup-UniversalFramework
    Exit $exitCode
}

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBYNJzVuDpt2l9t
# z9TGeU4kUYycZgMfahUTGAoEkaeoCaCCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQgkujOYeIr
# 20Z9NHgGAB+NQa7iOQlkgQlOVy6Qhy+jVxMwDQYJKoZIhvcNAQEBBQAEggEAH8Bm
# LrHkbtxlNypJFM3g/qKNnMXZf1cx16Lzyc7AdUU7D5N6jMjuwVTfcMYaotRltlFa
# 9zgGFpZMakZLybnQw3xAWCIb/vXB8IZn34UFdBQ9ZmHz7kbqxUWUqv/4U9jXbhkw
# O1mhamKwvsLKQAs1y0KVvbQE/p0vWu41RBJ/2mqAWHrxr3Vtw0E0NN0uzKX/Fb/Z
# 4d7gmfzyGEoc5v7z/DXdtS4kaoUe9Yj5ZM3jkNXh+IJHH5YWBeeePf5matRBKA1j
# i48icywEYunQhZoDLzeCrFDVFIXT1CJl6MYtC79ybdOxY6fbz/TU+/TteGrtee/O
# D0J0LoeH2TR4RC2+kg==
# SIG # End signature block
