$TEMP_DIR = $env:TEMP
$INSTALL_DIR = $TEMP_DIR + "\webreplay"
$CACHE_DIR = "cache"
$DOWNLOAD_DIR = $TEMP_DIR + "\webreplay_download"
$DEFAULT_CACHE_FILE = ""
$DEFAULT_WEBREPLAY_HTTPPORT = "8080"
$DEFAULT_WEBREPLAY_HTTPSPORT = "8443"

function import_certs
{
  $Rootparams =
  @{
    FilePath = "$INSTALL_DIR\certs\root_cert.pem"
    CertStoreLocation = 'Cert:\LocalMachine\Root'
  }

  $Intparams =
  @{
    FilePath = "$INSTALL_DIR\certs\int_cert.pem"
    CertStoreLocation = 'Cert:\LocalMachine\CA'
  }

  Import-Certificate @Rootparams
  Import-Certificate @Intparams
}

function install-webreplay
{
  if (Test-Path $INSTALL_DIR)
  {
    Remove-Item "$INSTALL_DIR\*" -Recurse -Force
  }
  else
  {
    New-Item -ItemType Directory -Path "$INSTALL_DIR"
  }
  New-Item -ItemType Directory -Path "$INSTALL_DIR\$CACHE_DIR"

  $settings = (Get-Content -Path "$PSScriptRoot\run_webreplay.json" | ConvertFrom-Json)
  if (Test-Path $DOWNLOAD_DIR)
  {
    Remove-Item "$DOWNLOAD_DIR\*" -Recurse -Force
  }
  else
  {
    New-Item -ItemType Directory -Force -Path "$DOWNLOAD_DIR"
  }

  $allow = Read-Host "We are going to download the web_replay related sfotware, do you allow? [y/n]"
  if ($allow -ieq "y")
  {
    Invoke-WebRequest $settings.ReleaseUrl -OutFile "$DOWNLOAD_DIR\web_replay.zip"
    Expand-Archive "$DOWNLOAD_DIR\web_replay.zip" -DestinationPath "$INSTALL_DIR"
  }
  #Invoke-WebRequest $settings.CacheArchiveUrl -OutFile "$DOWNLOAD_DIR\web_archive.zip"
  #Expand-Archive "$DOWNLOAD_DIR\web_archive.zip" -DestinationPath "$INSTALL_DIR\$CACHE_DIR"
  "The web_replay is installed, please install vcruntime140.dll."
}

function run-webreplay
{
  param (
    [string]$action = "replay",
    [string]$hostIp,
    [string]$httpPort = $DEFAULT_WEBREPLAY_HTTPPORT,
    [string]$httpsPort = $DEFAULT_WEBREPLAY_HTTPSPORT,
    [string]$cacheDir = "$CACHE_DIR",
    [string]$cacheFile = "$DEFAULT_CACHE_FILE"
  )

  "-- Opening firewall for web_replay.exe"
  $WEB_REPLAY_DIR = "$INSTALL_DIR"

  netsh advfirewall firewall delete rule name="AdkWebReplay" 2>&1
  netsh advfirewall firewall delete rule name="web_replay.exe" 2>&1

  $e = "netsh advfirewall firewall add rule name=`"AdkWebReplay`"" +  `
    " program=`"$WEB_REPLAY_DIR\bin\web_replay.exe`"" +  `
    " dir=in action=allow enable=yes localport=$httpPort,$httpsPort protocol=TCP"
  Invoke-Expression $e
  $e = "netsh advfirewall firewall add rule name=`"AdkWebReplay`"" +  `
    " program=`"$WEB_REPLAY_DIR\bin\web_replay.exe`"" +  `
    " dir=out action=allow enable=yes localport=$httpPort,$httpsPort protocol=TCP"
  Invoke-Expression $e

  Set-Location $WEB_REPLAY_DIR

  $ArchiveDir = "$WEB_REPLAY_DIR\$cacheDir"

  if ($cacheFile)
  {
    $Archive = "$ArchiveDir\$cacheFile"
  }
  else
  {
    $Archive = "$ArchiveDir"
  }

  if (Test-Path $ArchiveDir)
  {
    if ($action -ieq "record")
    {
      if ($cacheFile)
      {
        if (Test-Path $Archive)
        {
          Remove-Item -Path "$Archive" -Recurse -Force
        }
      }
      else
      {
        Remove-Item -Path "$Archive" -Recurse -Force
      }
    }
  }

  if ($action -ieq "record")
  {
    .\bin\web_replay.exe $action --host=$hostIp --http_port=$httpPort --https_port=$httpsPort $Archive
  }
  elseif ($action -ieq "replay")
  {
    .\bin\web_replay.exe $action --host=$hostIp --http_port=$httpPort --https_port=$httpsPort --excludes_list="edge ntp" $Archive
  }
  else
  {
    Write-Host "Unsupported action: $action"
  }
}

function show-help
{
  Write-Host "Usage:`n"  `
             " run_webreplay install`n"  `
             " run_webreplay record  <Local LAN IP> [<cacheFile> <HTTP port> <HTTPS port>]`n"  `
             " run_webreplay replay  <Local LAN IP> [<cacheFile> <HTTP port> <HTTPS port>]`n"  `
             "`n"  `
             "Description:`n"  `
             " <cacheFile> not specified is defaulted to `"$DEFAULT_CACHE_FILE`", you can specify <scenario>.json.gz`n"  `
             " <HTTP port> not specified is defaulted to $DEFAULT_WEBREPLAY_HTTPPORT`n"  `
             " <HTTPS port> not specified is defaulted to $DEFAULT_WEBREPLAY_HTTPSPORT`n"  `
             "`n"  `
             "Examples:`n"  `
             " run_webreplay install`n"  `
             " run_webreplay record 192.168.4.180`n"  `
             " run_webreplay record 192.168.4.180 `"<scenario>.json.gz`"`n"  `
             " run_webreplay record 192.168.4.180 `"<scenario>.json.gz`" $DEFAULT_WEBREPLAY_HTTPPORT`n"  `
             " run_webreplay record 192.168.4.180 `"<scenario>.json.gz`" $DEFAULT_WEBREPLAY_HTTPPORT $DEFAULT_WEBREPLAY_HTTPSPORT`n"  `
             " run_webreplay replay 192.168.4.180`n"  `
             " run_webreplay replay 192.168.4.180 `"<scenario>.json.gz`"`n"  `
             " run_webreplay replay 192.168.4.180 `"<scenario>.json.gz`" $DEFAULT_WEBREPLAY_HTTPPORT`n"  `
             " run_webreplay replay 192.168.4.180 `"<scenario>.json.gz`" $DEFAULT_WEBREPLAY_HTTPPORT $DEFAULT_WEBREPLAY_HTTPSPORT`n"  `
             "`n"
}

try
{
  $CurrLoc = Get-Location

  $code=@'
  [DllImport("kernel32.dll", CharSet = CharSet.Auto,SetLastError = true)]
  public static extern void SetThreadExecutionState(uint esFlags);
'@

  # prevent this machine from sleep
  $ste = Add-Type -memberDefinition $code -name System -namespace Win32 -passThru
  $ES_CONTINUOUS = [uint32]"0x80000000"
  $ES_AWAYMODE_REQUIRED = [uint32]"0x00000040"
  $ES_DISPLAY_REQUIRED = [uint32]"0x00000002"
  $ES_SYSTEM_REQUIRED = [uint32]"0x00000001"
  $ste::SetThreadExecutionState($ES_CONTINUOUS -bor $ES_DISPLAY_REQUIRED)

  $ScriptFolderPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
  $DefaultConfigJson = "$ScriptFolderPath\default.config.json"

  if (Test-Path $DefaultConfigJson)
  {
      $defaulteConfig = (Get-Content -Path $DefaultConfigJson | ConvertFrom-Json)
      $DEFAULT_WEBREPLAY_HTTPPORT = $defaulteConfig.WebreplayHTTPPort
      $DEFAULT_WEBREPLAY_HTTPSPORT = $defaulteConfig.WebreplayHTTPSPort
  }

  if ($args[0] -ieq "install")
  {
    install-webreplay
    import_certs
  }
  elseif (($args[0] -ieq "record") -or ($args[0] -ieq "replay"))
  {
    if (-not(($args.Count -ge 2) -and ($args.Count -le 5)))
    {
      show-help
      return
    }

    $cacheFile = ""
    $httpPort = $DEFAULT_WEBREPLAY_HTTPPORT
    $httpsPort = $DEFAULT_WEBREPLAY_HTTPSPORT

    if ($args.Count -ge 3) { $cacheFile = $args[2] }
    if ($args.Count -ge 4) { $httpPort = $args[3] }
    if ($args.Count -ge 5) { $httpsPort = $args[4] }

    run-webreplay -action "$($args[0])" -hostIp $args[1] -httpPort $httpPort -httpsPort $httpsPort -cacheFile "$cacheFile"
  }
  else
  {
    show-help
  }
}
finally
{
  $ste::SetThreadExecutionState($ES_CONTINUOUS)
  Set-Location $CurrLoc
}

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDPmpPAWGpk/DWO
# ZeNTreNI+yhMVgL4g8Gbv4VgOkzm7KCCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQg7X/EJB6o
# fMbkI8fYJOzXLP2oArtz8MfSVNbY+2Leo5IwDQYJKoZIhvcNAQEBBQAEggEASDV1
# 7ePY1EzznC/Z9H8DTJb/wqDV1CvWxso2Duuxew9akfSxrZgGvPzCloinmpzxD9TT
# ljW1UONQnV1fIJ1RKW5MAmUh1pVHZndfLUWujQETV/6irn3LzG8BNH4uShHWndIL
# 367P8oWFxVpvSFmUuJjMUkeFV5ZHtok8ERJCeDUg3To+OVTVgrMD6hsI/dzv1u5Z
# DtrMXHNUopzaMPy6DCifcCxgqdywrZQm0pTNID9UvyWZxSq7qrnKI7ownaUVFQXM
# oCv4ACDbLoUq5zAHHfwSMKKNxWnb0t7066BDrnOSj3JCjg1wnM0zX8wZW54ak9J5
# iJQ20xQLYwnkqoXAhA==
# SIG # End signature block
