<#
    .SYNOPSIS
    Edge Automation Hours of Battery Life Workload Assessment

    .DESCRIPTION
    Automates Edge Browsing Activations.

    .PARAMETER Iterations
    Integer, execution iterations.

    .PARAMETER ScenarioIndex
    Integer, scenario json file index. 0 : scenario.default.json, 1 : scenario.browsing.json, 2 : scenario.office.json, 3 : scenario.skype.json

    .PARAMETER SenderEmailAddress
    string, sender email address.

    .PARAMETER MeetingInvitationUrl
    string, meeting invitation URL.

    .PARAMETER ScenarioDurationSecs
    Integer, scenario json duration in seconds.

    .PARAMETER EmulationEnabled
    switch, enable browser device emulation.

    .PARAMETER ScreenHeight
    Integer, emulated screen height.

    .PARAMETER ScreenWidth
    Integer, emulated screen width.

    .PARAMETER PixelRatio
    Double, emulated screen pixel ratio.

    .PARAMETER LocalDebuggingLaunch
    switch, use browser local debugging port for automation control.

    .PARAMETER ForceImmediateSleepingTabs
    switch, disable sleeping tabs feature timeout.

    .PARAMETER CollectHistograms
    switch, save edge:\\histograms web page to results.

    .EXAMPLE
    EdgeAutomation -Iterations 1 -ScenarioIndex 2 -Mode 0
                   -SenderEmailAddress 'youremail@outlook.com'
                   -MeetingInvitationUrl 'https://join.skype.com/U2Nrhn5Z1goS'
                   -ScenarioDurationSecs 900
#>

Param(
    [parameter(Mandatory = $true)]
    [int32]
    $Iterations,

    [parameter(Mandatory = $true)]
    [int32]
    $ScenarioIndex,

    [parameter(Mandatory = $true)]
    [int32]
    $Mode,

    [parameter(Mandatory = $false)]
    [string]
    $SenderEmailAddress = '',

    [parameter(Mandatory = $false)]
    [string]
    $MeetingInvitationUrl = '',

    [parameter(Mandatory = $false)]
    [int32]
    $ScenarioDurationSecs = 1800,

    [parameter(Mandatory = $false)]
    [string]
    $CredentialFilePath = '',

    [parameter(Mandatory = $false)]
    [switch]
    $EnableLC,

    [parameter(Mandatory = $false)]
    [string]
    $YoutubeUrl = $null,

    [parameter(Mandatory = $false)]
    [switch]
    $EmulationEnabled = $false,

    [parameter(Mandatory = $false)]
    [int32]
    $ScreenHeight = 0,

    [parameter(Mandatory = $false)]
    [int32]
    $ScreenWidth = 0,

    [parameter(Mandatory = $false)]
    [double]
    $PixelRatio = 1.0,

    [parameter(Mandatory = $false)]
    [switch]
    $LocalDebuggingLaunch,

    [parameter(Mandatory = $false)]
    [switch]
    $ForceImmediateSleepingTabs,

    [parameter(Mandatory = $false)]
    [switch]
    $CollectHistograms,

    [parameter(Mandatory = $false)]
    [switch]
    $SteadyStateTrace = $false,

    [parameter(Mandatory = $false)]
    [switch]
    $WebreplayEnabled = $false,

    [parameter(Mandatory = $false)]
    [string]
    $TextLogOutput = $null
)

# Exit $exitCode will not affect the real return code but it will affect return code 0 ($exitCode == 0) or 1 ($exitCode != 0) no matter run by powershell.exe -Command or -File.
$exitCode = 0
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

New-Variable -Name TestExe -Value "EdgeAutomationHost.exe" -Option Constant

function Get-AblPrepareArguments
{
    Param(
        [switch]
        $LocalDebuggingLaunch,

        [PSCustomObject]
        $config,

        [string]
        # "Abl", we might support "Abl2023" (scenario.browsing_abl2023.json) and "Abl2024" (scenario.browsing_abl2024.json) in future
        $ablIdentity
    )

    $ablArgs = "/LiveUpdate"

    if ($LocalDebuggingLaunch) { $ablArgs += " /LocalDebuggingLaunch" }

    $ablArgs = " /ParameterReplaceFile parameters.$($ablIdentity).credentials.json"

    $ablArgs += if ($config.UseChrome) { " /BrowsingProfile scenario.browsing_$($ablIdentity).chrome.prep.json" }  `
        else { " /BrowsingProfile scenario.browsing_$($ablIdentity).prep.json" }

    if ($Global:debugFlag) { $ablArgs += " /Debug /TextLogOutput adk\$($ablIdentity)PrepLog.txt" }

    return $ablArgs
}

try
{
    #*****************************************************************
    #
    #                Definitions and imports
    #
    #*****************************************************************

    #set to true if you need to hang the script at the end to check console output
    $Global:debugFlag = $false

    # Tools and resources
    $Global:AxeUniversalPath = Convert-Path((Get-Item env:\AssessmentAxeUniversalPath -ErrorAction Stop).value)
    $Global:InvocationPath   = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

    try
    {
        # Import the modules and functions
        Import-Module "$AxeUniversalPath\UniversalAssessment.psm1" -ErrorAction Stop
    }
    catch
    {
        $exitCode = 100
        throw "[Amst-<EdgeAutomation>][ExecuteWorkload]Failed to import $AxeUniversalPath\UniversalAssessment.psm1"
    }

    Initialize-UniversalFramework -InvocationPath $InvocationPath -AxeUniversalPath $AxeUniversalPath

    $defaultConfigJson = "$InvocationPath\default.config.json"
    $config = (Get-Content -Path "$defaultConfigJson" | ConvertFrom-Json)

    if (($ScenarioIndex -lt 0) -or ($ScenarioIndex -ge $config.OrdinalScenarioFileList.Count))
    {
        $exitCode = 120
        throw ("[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]ScenarioIndex: $ScenarioIndex is out of range.")
    }

    $scenarioJson = $config.OrdinalScenarioFileList[$ScenarioIndex]

    # $scenario == "browsing", "browsing_abl", "netfix", "skype", "youtubetos", "browsing_abl.prep", or ...
    $scenario = if ($scenarioJson -imatch 'scenario.(.+).json') { "$($Matches.1)" } else { "" }
    # $ablIdentity might be "Abl" or ""
    $ablIdentity = if ($scenario -imatch 'browsing_abl(.*)(_cn)?') { "Abl$($Matches.1)" } else { "" }
    # credential file for ABL
    if ($ablIdentity) { $CredentialFilePath = "parameters.$($ablIdentity).credentials.json" }

    if ($Global:debugFlag)
    {
        $winStyle = "Minimized"
    }
    else
    {
        $winStyle = if ($((Get-Process -Id $PID).MainWindowHandle) -eq 0) { "Hidden" } else { "Minimized" }
    }

    if ($Mode -eq 1)
    {
        #*****************************************************************
        #
        #                Prepare training!
        #
        #*****************************************************************

        if (($scenarioJson -ieq "scenario.browsing.json") -or ($scenarioJson -ieq "scenario.youtube.custom.json") -or
            ($scenarioJson -ieq "scenario.youtube.json") -or ($scenarioJson -ieq "scenario.youtubetos.json"))
        {
        }
        elseif (($scenarioJson -ieq "scenario.browsing_abl.json") -or ($scenarioJson -ieq "scenario.browsing_abl_cn.json"))
        {
            $teArgs = Get-AblPrepareArguments -LocalDebuggingLaunch $LocalDebuggingLaunch -config $config -ablIdentity "$($ablIdentity)"

            "Prepare training start $TestExe $teArgs." | Log-Info
            $proc = Start-Process $Global:InvocationPath\$(Get-RealProcessorArchitecture)\$TestExe -ArgumentList $teArgs -PassThru -WindowStyle $winStyle
            $handle = $proc.Handle # cache proc.Handle
            $proc.WaitForExit();
            if ($proc.ExitCode -ne 0)
            {
                $exitCode = 130
                throw ("[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]$TestExe $teArgs return error $($proc.ExitCode).")
            }
            "$TestExe $teArgs is done." | Log-Info
        }
        else
        {
            $exitCode = 140
            throw ("[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]This scenario json file '$scenarioJson' is not supported for training.")
        }
    }

    #*****************************************************************
    #
    #                Actual workload!
    #
    #*****************************************************************

    $teArgs = "/Iterations $Iterations"

    $teArgs += " /Mode $Mode"
    $teArgs += " /ScenarioIndex $scenarioIndex"

    if ($LocalDebuggingLaunch)
    {
        $teArgs += " /LocalDebuggingLaunch"
    }

    if ($ForceImmediateSleepingTabs)
    {
        $teArgs += " /ForceImmediateSleepingTabs"
    }

    if ($CollectHistograms)
    {
        $teArgs += " /CollectHistograms"
    }

    if ($Global:debugFlag)
    {
        $teArgs += " /Debug"
        if (-not $TextLogOutput) { $TextLogOutput = "adk\$($scenario)$($Mode)Log.txt" }
    }

    if ($TextLogOutput)
    {
        $teArgs += " /TextLogOutput `"$TextLogOutput`""
    }

    if ($EmulationEnabled)
    {
        $teArgs += " /EmulationEnabled /ScreenHeight $ScreenHeight /ScreenWidth $ScreenWidth /PixelRatio `"$PixelRatio`""
    }

    if ($CredentialFilePath)
    {
        $teArgs += " /ParameterReplaceFile `"$CredentialFilePath`""
    }

    if ($SteadyStateTrace)
    {
        $teArgs += " /SteadyStateTrace `"$SteadyStateTrace`""
    }

    if ($WebreplayEnabled)
    {
        $teArgs += " /WebreplayEnabled `"$WebreplayEnabled`""
    }

    # json related arguments
    if ($ScenarioDurationSecs)
    {
        $teArgs += " /json.ScenarioDurationSecs `"$ScenarioDurationSecs`""
    }
    if ($SenderEmailAddress)
    {
        $teArgs += " /json.SenderEmailAddress `"$SenderEmailAddress`""
    }
    if ($MeetingInvitationUrl)
    {
        $teArgs += " /json.MeetingInvitationUrl `"$MeetingInvitationUrl`""
    }
    if ($YoutubeUrl)
    {
        $teArgs += " /json.YoutubeUrl `"$YoutubeUrl`""
    }
    $teArgs += " /json.EnableLC `"$EnableLC`""

    "Start $TestExe $teArgs." | Log-Info
    $proc = Start-Process $Global:InvocationPath\$(Get-RealProcessorArchitecture)\$TestExe -ArgumentList $teArgs -PassThru -WindowStyle $winStyle
    $handle = $proc.Handle # cache proc.Handle
    $proc.WaitForExit();
    $exitCode = $proc.ExitCode

    if ($exitCode -ne 0)
    {
        throw ("[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]EdgeAutomationHost.exe exited with errors LastExitCode:{0}" -f $exitCode)
    }

    if ($EnableLC)
    {
        Add-Type -AssemblyName @('UIAutomationClient', 'UIAutomationTypes')
        $proc = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue
        # check if the process is not running
        if (-not $proc) {
            "LiveCaptions is not running." | Log-Error
            throw "LiveCaptions is not running."
        }
        $handleLiveCaptions = $proc.MainWindowHandle
        if (-not $handleLiveCaptions) {
            "Unable to locate LiveCaptions." | Log-Error
            throw "Unable to locate LiveCaptions."
        }
        $rootLiveCaptions = [System.Windows.Automation.AutomationElement]::FromHandle($handleLiveCaptions)
        $wp = $rootLiveCaptions.GetCurrentPattern([System.Windows.Automation.WindowPatternIdentifiers]::Pattern)
        if ($wp) {
            $wp.Close()
        }
    }
    "$TestExe $teArgs is done." | Log-Info

    Start-Sleep 5
}
catch
{
    Handle-UniversalFrameworkException -Exception $_
}
finally
{
    Cleanup-UniversalFramework
    Exit $exitCode
}

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAQyeHVF8cA8eMV
# kNtNDQF+Da3gPfi+0P8EMUYY2Zqp86CCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQgr6mlPDP5
# AMiG1LsrmzZJB0Tx8MVTGLLdoTtx29lOrBowDQYJKoZIhvcNAQEBBQAEggEAS5OY
# tIsInjOT1fkRJ/uFC3c1vcUjgfwHH2Q0nUOAoMqSlhyc14oaTYOOMF5XC2V8HDs6
# WFhmD2qJ2ujMrvlBrgNJ+FlqIfCLrU19veWWHwRWy/RJQxq0p5ki4JENQ9Aorf4o
# U7ItoWIThpXy1pkvErr/ISH7Eo34yM5YBdmwVyFLF8OHBoycVc8l4NrMoBonLyBN
# KCeBBpd1tlbNesHTnjNMZx/aw7mX8KuiwiiCrIf0S0tMvfz/A/N3jrugOP94geQ4
# g6KbNL1QseNKDMTEit6o2TTHLyNO7/YfJd3TwPqP52CcmI7Y6DL7aMJI0tPHFSBV
# m7QMOMlQwLfRIQbO2A==
# SIG # End signature block
