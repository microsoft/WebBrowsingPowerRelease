start "" "%~dp0%PROCESSOR_ARCHITECTURE%\AL.exe" "%~dp0Job_Training.xml" 
