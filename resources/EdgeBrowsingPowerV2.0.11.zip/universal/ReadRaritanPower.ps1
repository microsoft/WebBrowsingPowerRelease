<#
    .SYNOPSIS
    Calculates Power Consumption data from the PDU controller.

    .DESCRIPTION
    Calculates Power Consumption data.

    .PARAMETER ReadPower
    String, executable to get the power data.

    .PARAMETER Stage
    String, execution stage. Either pre stage (run before all assessments) or post stage (run after all assessments).

    .PARAMETER IP
    String, PI address of the PDU controller.

    .PARAMETER Username
    String, user name of the PDU controller.

    .PARAMETER Password
    String, user password of the PDU controller.

    .PARAMETER Outlet
    Integer, Outlet of the controller.

    .EXAMPLE
    ReadRaritanPower.ps1 -ReadPower 'Python #%AssessmentAxeUniversalPath%\ReadRaritanPower.py#'
                         -Stage Pre
                         -Config "%AssessmentAxeUniversalPath%\ReadRaritanPower.config.json"
#>

Param(
    [AllowEmptyString()]
    [parameter(Mandatory = $true)]
    [string]
    $ReadPower = "",

    [parameter(Mandatory = $true)]
    [string]
    $Stage = ""
)

# Exit $exitCode will not affect the real return code but it will affect return code 0 ($exitCode == 0) or 1 ($exitCode != 0) no matter run by powershell.exe -Command or -File.
$exitCode = 0
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

New-Variable -Name AcPowerXml -Value "AcPower.Xml" -Option Constant
New-Variable -Name AcPowerErr -Value "AcPowerErr.txt" -Option Constant
$InitializeUniversalFramework = $false

try
{
    $JobSettingsJson = "C:\Data\test\bin\adk\job.settings.json"
    if (-not (Test-Path $JobSettingsJson)) { return; }

    # If we are not interested in AC energy test, we should end this script as soon as possible.
    $jobSettings = (Get-Content -Path $JobSettingsJson | ConvertFrom-Json)
    if (-not $jobSettings.EnableAcTest) { return }

    #*****************************************************************
    #
    #                Definitions and imports
    #
    #*****************************************************************

    #set to true if you need to hang the script at the end to check console output
    $Global:debugFlag = $false

    # Tools and resources
    $Global:AxeUniversalPath = Convert-Path((Get-Item env:\AssessmentAxeUniversalPath -ErrorAction Stop).value)
    $Global:InvocationPath   = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

    try
    {
        # Import the modules and functions
        Import-Module "$AxeUniversalPath\UniversalAssessment.psm1" -ErrorAction Stop
    }
    catch
    {
        $exitCode = 100
        throw "[Job][User?ExecuteWorkload]Failed to import $AxeUniversalPath\UniversalAssessment.psm1"
    }

    Initialize-UniversalFramework -InvocationPath $InvocationPath -AxeUniversalPath $AxeUniversalPath
    $InitializeUniversalFramework = $true

    $Config = (Join-Path -Path ($Global:AxeUniversalPath) "ReadRaritanPower.config.json")
    $configPdu = (Get-Content -Path "$Config" | ConvertFrom-Json)

    $fullPathAcPowerXml = "$($Global:EnergyPersistentResultsFolder)\$AcPowerXml"
    $fullPathAcPowerErr = "$AXEResultsPath\$Stage$AcPowerErr"

    if (!$ReadPower)
    { # There is no ReadPower command! Please input power data manually.
        $configPdu.ManuallyEnterEnergyValue = $true
    }

    if (-not (Test-Path $fullPathAcPowerXml))
    {
        "<root></root>" > $fullPathAcPowerXml
    }
    $AcPowerXmlDoc = [xml](Get-Content -Path $fullPathAcPowerXml)

    if ($Stage -ieq "Pre")
    {
        if (-not $configPdu.ManuallyEnterEnergyValue)
        {
            # list all fields in config.json and there should be no empty string in these fields
            $configFields = @( "IP", "Username", "Password", "Outlet", "PythonId", "RaritanPduRpcSdkUrl", "ManuallyEnterEnergyValue" )
            foreach ($field in $configFields)
            {
                if (!($configPdu.PSobject.Properties.name -match $field))
                {
                    throw "Missing field:$field in $Config"
                }
                if ($($configPdu."$field") -is [string])
                {
                    if (!$($configPdu."$field"))
                    {
                        throw "Invalid value of $field in $Config"
                    }
                }
            }
            [ipaddress]$($configPdu.IP)

            if ($configPdu.Outlet -lt 0)
            {
                [int]$configPdu.Outlet = Read-Host "`nIP:$($configPdu.IP) Username:$($configPdu.Username) Password:$($configPdu.Password)`nWhat is the Outlet number? "
            }
        }
    }
    else
    {
        if ($configPdu.Outlet -lt 0)
        {
            # We only ask Outlet in Pre Stage.
            [int]$configPdu.Outlet = $AcPowerXmlDoc.DocumentElement.Outlet
        }
    }

    $LastExitCode = 0
    if ($configPdu.ManuallyEnterEnergyValue)
    {
        if ($Stage -ieq "Pre")
        {
            [double]$activeEnergy = Read-Host "`n`nInput power data at start (mWh)? "
        }
        elseif ($Stage -ieq "Post")
        {
            [double]$activeEnergy = Read-Host "`n`nInput power data at end (mWh)? "
        }
        $CurrentPowerResult = "{ 'ActiveEnergy': $activeEnergy }" 2> $fullPathAcPowerErr
    }
    else
    {
        [string]$cmdReadPower = ($ReadPower, $configPdu.IP, $configPdu.Username, $configPdu.Password, $configPdu.Outlet)
        $CurrentPowerResult = (Invoke-Expression $cmdReadPower 2> $fullPathPowerErr)
    }

    $lxc = $LastExitCode
    $CurrentPower = ($CurrentPowerResult | ConvertFrom-Json)
    if ($CurrentPower.Log)
    {
        "[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]ReadPower Log:`n$($CurrentPower.Log)" | Log-Info
    }

    if ($CurrentPower.Exception)
    {
        $exitCode = 101
        throw $CurrentPower.Exception
    }

    if ($lxc -ne 0)
    {
        if ((Get-Item $fullPathAcPowerErr).length -gt 0)
        {
            $exitCode = 102
            throw "[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]" + (Get-Content $fullPathAcPowerErr)
        }
        else
        {
            throw "[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]ReadPower LastExitCode:$lxc"
        }
    }

    if ($Stage -ieq "Pre")
    {
        # We will not create Outlet node for the second workload, all workloads share one Outlet.
        if ($AcPowerXmlDoc.DocumentElement.Outlet -eq $null)
        {
            # handle Outlet
            [Xml.XmlText]$OutletValue = $AcPowerXmlDoc.CreateTextNode("$($configPdu.Outlet)")

            [Xml.XmlElement]$Outlet = $AcPowerXmlDoc.CreateElement("Outlet")
            $Outlet.AppendChild($OutletValue)

            # add Outlet as a child of root
            $AcPowerXmlDoc.DocumentElement.AppendChild($Outlet)
        }

        # handle the current ActiveEnergy
        [Xml.XmlText]$ActiveEnergyValue = $AcPowerXmlDoc.CreateTextNode("$($CurrentPower.ActiveEnergy)")

        [Xml.XmlElement]$ActiveEnergy = $AcPowerXmlDoc.CreateElement("ActiveEnergy")
        $ActiveEnergy.AppendChild($ActiveEnergyValue)

        # add $ActiveEnergy as a child of $Pre
        [Xml.XmlElement]$Pre = $AcPowerXmlDoc.CreateElement("Pre")
        $Pre.AppendChild($ActiveEnergy)

        # add $Pre as a child of $Wrkload (Asmt-EdgeAutomationWorkload-0...)
        [Xml.XmlElement]$Workload = $AcPowerXmlDoc.CreateElement("$($Global:AxeAsmtName)")
        $Workload.AppendChild($Pre)

        # add $Workload (Asmt-EdgeAutomationWorkload-0...) as a child of root
        $AcPowerXmlDoc.DocumentElement.AppendChild($Workload)
        $AcPowerXmlDoc.Save($fullPathAcPowerXml)
    }
    elseif ($Stage -ieq "Post")
    {
        # handle the current ActiveEnergy
        [Xml.XmlText]$ActiveEnergyValue = $AcPowerXmlDoc.CreateTextNode("$($CurrentPower.ActiveEnergy)")

        [Xml.XmlElement]$ActiveEnergy = $AcPowerXmlDoc.CreateElement("ActiveEnergy")
        $ActiveEnergy.AppendChild($ActiveEnergyValue)

        # add $ActiveEnergy as a child of $Post
        [Xml.XmlElement]$Post = $AcPowerXmlDoc.CreateElement("Post")
        $Post.AppendChild($ActiveEnergy)

        # add $Post as a child of $Wrkload (Asmt-EdgeAutomationWorkload-0...)
        [Xml.XmlElement]$Workload = $AcPowerXmlDoc.DocumentElement."$($Global:AxeAsmtName)"
        $Workload.AppendChild($Post)

        $AcPowerXmlDoc.Save($fullPathAcPowerXml)
    }
    else
    {
        $exitCode = 103
        throw "[$($Global:AxeAsmtName)][$($Global:AxeAsmtExecuteWorkloadTag)]Invalid input parameter Stage:$Stage."
    }
}
catch
{
    Handle-UniversalFrameworkException -Exception $_
}
finally
{
    if ($InitializeUniversalFramework) { Cleanup-UniversalFramework }
    Exit $exitCode
}

# SIG # Begin signature block
# MIIOqQYJKoZIhvcNAQcCoIIOmjCCDpYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBcdLA9gyJwK4Uz
# /N0C9Zfc05x65ShnYxthVBNGnmYWJ6CCC6gwggUNMIID9aADAgECAhMzAAAHKLFq
# WQnfUJEsAAEAAAcoMA0GCSqGSIb3DQEBCwUAMHkxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBD
# QSAyMDEwMB4XDTI1MDIxMzE5MDkxMloXDTI2MDUxMzE5MDkxMlowdDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwZv4
# O3X1zuXN58sgg/Qg6VbyZpqwWWAmXf/zm5K7NQNhaZEk5/FKzkuOB/66YH0q5HLC
# gW66A6Lmbm8lEFyJKgPAXMVBHgoRJpM5tPlX+n8FBikv6Yg9f0nFpYuobfA8seoE
# nz0ryUfDn6KahiqC/kYmpWI7qY/EESUVCft+M/bF+8dZb0nhvPH35RJuOxiqDx6Z
# oM08HUpqNzpJ0zlNQXwBqZ+QfIDcvdC05Y/s/+tDA4ExaR3PP0DMItwjapGyTvXZ
# OJwtxnGs883F2VNk/+fhhIr6Y9L/CslEKZdgT1P2X5RgeD5dD9J3t5Kd/7rllpqr
# s3zD3EzTNKbu/osa4QIDAQABo4IBkTCCAY0wDAYDVR0TAQH/BAIwADAOBgNVHQ8B
# Af8EBAMCB4AwHQYDVR0OBBYEFP1xV+Piluei2PNSnI4hwUtIL5ZRMB8GA1UdJQQY
# MBYGCCsGAQUFBwMDBgorBgEEAYI3CgMVMEMGCSsGAQQBgjcUAgQ2HjQATQBTAEkA
# VABUAGUAcwB0AEMAbwBkAGUAUwBpAGcAbgBpAG4AZwBTAGgAYQAyAC0AQwBTMB8G
# A1UdIwQYMBaAFL9loqtvdaNORZZXBc85h/TAFRwcMFwGA1UdHwRVMFMwUaBPoE2G
# S2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRlc3RpbmclMjBQQ0ElMjAyMDEwKDEpLmNybDBpBggrBgEFBQcBAQRdMFswWQYI
# KwYBBQUHMAKGTWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwVGVzdGluZyUyMFBDQSUyMDIwMTAoMSkuY3J0MA0GCSqGSIb3
# DQEBCwUAA4IBAQBXojtW9EseHdyc8ZQThMb8V994wCs97IQMueGM0ajpxZDZb8Bj
# p5GkTOQb9gRLGqnXuSJt055vdJyyYURSEzo+oQNSpTV8q8A3q8M/Vm/p9gduaU6m
# +R/E3BIpgABwqVxJWYJEo3HimIXrWBwvA3Q+gKRxUSA+GTUntS4eAu5Bfy9sINLr
# p7sOXULwuNhKqAWWe2LL7m+kO++v3SedL62Y4htHWRq45Jyu76AtlZpCxXkW4gug
# TfaAYOsyHOPgZgbWs/00iZrOKnfiQRTKG1HopFohLGOvr9VBq9RD3TDDZRur22rD
# w4t3w63n2BUUwICHtpbDL36r3AZqNoVC8MVAMIIGkzCCBHugAwIBAgITMwAAAC01
# ekaIyQdx2AAAAAAALTANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjE6MDgGA1UEAxMxTWljcm9zb2Z0IFRlc3Rpbmcg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMDEyMTAyMDQzMjBa
# Fw0zNTA2MTcyMTA0MTFaMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvzxggau+7P/XF2PypkLRE2KcsBfO
# ukYaeyIuVXOaVLnG1NHKmP53Rw2OnfBezPhU7/LPKtRi8ak0CgTXxQWG8hD1TdOW
# CGaF2wJ9GNzieiOnmildrnkYzwxj8Br/gampQz+pC7lR8bNIOvxELl8RxVY6/8oO
# zYgIwf3H1fU+7+pOG3KLI71FN54fcMGnybggc+3zbD2LIQXPdxL+odwH6Q1beAls
# MlUQR9A3yMf3+nP+RjTkVhaoN2RT1jX7w4C2jraGkaEQ1sFK9uN61BEKst4unhCX
# 4IGuEl2IAV3MpMQoUpxg8ArmiK9L6VeK7KMPNx4p9l0h09faXQ7JTtuNbQIDAQAB
# o4IB+jCCAfYwDgYDVR0PAQH/BAQDAgGGMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJ
# KwYBBAGCNxUCBBYEFOqfXzO20F+erestpsECu0A4y+e1MB0GA1UdDgQWBBS/ZaKr
# b3WjTkWWVwXPOYf0wBUcHDBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRv
# cnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAUowEEfjCIM+u5MZzK64V2Z/xltNEwWQYDVR0fBFIwUDBO
# oEygSoZIaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljVGVzUm9vQ2VyQXV0XzIwMTAtMDYtMTcuY3JsMIGNBggrBgEFBQcBAQSBgDB+
# ME0GCCsGAQUFBzAChkFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Rlc1Jvb0NlckF1dF8yMDEwLTA2LTE3LmNydDAtBggrBgEFBQcwAYYhaHR0
# cDovL29uZW9jc3AubWljcm9zb2Z0LmNvbS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IC
# AQAntNCFsp7MD6QqU3PVbdrXMQDI9v9jyPYBEbUYktrctPmvJuj8Snm9wWewiAN5
# Zc81NQVYjuKDBpb1un4SWVCb4PDVPZ0J87tGzYe9dOJ30EYGeiIaaStkLLmLOYAM
# 6oInIqIwVyIk2SE/q2lGt8OvwcZevNmPkVYjk6nyJi5EdvS6ciPRmW9bRWRT4pWU
# 8bZIQL938LE4lHOQAixrAQiWes5Szp2U85E0nLdaDr5w/I28J/Z1+4zW1Nao1prV
# COqrosnoNUfVf1kvswfW3FY2l1PiAYp8sGyO57GaztXdBoEOBcDLedfcPra9+NLd
# EF36NkE0g+9dbokFY7KxhUJ8WpMiCmN4yj9LKFLvQbctGMJJY9EwHFifm2pgaiaa
# fKF1Gyz+NruJzEEgpysMo/f9AVBQ/qCdPQQGEWp3QDIaef4ts9QTx+RmDKCBDMTF
# LgFmmhbtUY0JWjLkKn7soz/LIcDUle/p5TiFD4VhfZnAcvYQHXfuslnyp+yuhWzA
# SnAQNnOIO6fc1JFIwkDkcM+k/TspfAajzHooSAwXkrOWrjRDV6wI0YzMVHrEyQ0h
# Z5NnIXbL3lrTkOPjf3NBu1naSNEaySduStDbFVjV3TXoENEnZiugJKYSwmhzoYHM
# 1ngipN5rNdqJiK5ukp6E8LDzi3l5/7XctJQY3+ZgHDJosjGCAlcwggJTAgEBMIGQ
# MHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMT
# Gk1pY3Jvc29mdCBUZXN0aW5nIFBDQSAyMDEwAhMzAAAHKLFqWQnfUJEsAAEAAAco
# MA0GCWCGSAFlAwQCAQUAoIGYMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
# CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCwGCisGAQQBgjcCAQwxHjAcoBqA
# GABTAFMAQwBcAFIAbgBEAGMAYgBsAGQAQjAvBgkqhkiG9w0BCQQxIgQggSTIfvhd
# QI2uivaPSsY1a7fMl28fctUgg+rOf1iCi6EwDQYJKoZIhvcNAQEBBQAEggEAl2uW
# zeu0BAxfxBWc0UMrOhmj6srbqoGCsUFAcUDvpvaGdkPvp/5mFE11t7PDXxdvwBC0
# oqdn81kpjv6U8Rjrb51hPiQBsOo2nFRyqTUVKtwyM1AwJD7T8sg6v4+IOQjUP44A
# KCPovIQDzmtVnIrxIu1u0nDbMMWh8d0IB8qTHAACmQPhGcIuiuQ2br8ZKs//XjXY
# UEgU055tiKGe+JPNnmdkSIBa62zDCopwXzWf6qG1yMEB2OipZsMl0QoBHq13QayB
# 70VggcHGRZjtab3dVVH83taQlZBuHh+u0ru90dstg+lzBv/mlYTw3Sx4REkhrvD4
# QBc6rpq7e1lioL75hw==
# SIG # End signature block
