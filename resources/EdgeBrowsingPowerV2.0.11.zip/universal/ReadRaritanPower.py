import sys
from raritan import rpc
from raritan.rpc import pdumodel
import json

try:
    ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    outlet_index = int(sys.argv[4])

    agent = rpc.Agent("https", ip, username, password, disable_certificate_verification = True)
    pdu = pdumodel.Pdu("/model/pdu/0", agent)
    outlets = pdu.getOutlets()

    dic = {}
    dic["Log"] = "Start reading active energy for outlet " + str(outlet_index) + ".\n"
    dic["ActiveEnergy"] = outlets[outlet_index].getSensors().activeEnergy.getReading().value * 1000.0
    dic["Log"] += "End reading active energy: " + str(dic["ActiveEnergy"]) +".\n"
    print(json.dumps(dic))
except Exception as err:
    dic = {}
    dic["Exception"] = f"Unexpected {err}, {type(err)}"
    print(json.dumps(dic))
